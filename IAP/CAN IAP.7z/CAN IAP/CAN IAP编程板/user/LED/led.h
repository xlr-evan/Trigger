/****************************************Copyright (c)****************************************************
**                                 http://www.openmcu.com
**--------------File Info---------------------------------------------------------------------------------
** File name:           LED.h
** Last modified Date:  2012-07-23
** Last Version:        V1.00
** Descriptions:        
**
**--------------------------------------------------------------------------------------------------------
** Created by:          openmcu
** Created date:        2012-07-23
** Version:             V1.00
** Descriptions:        ��дʾ������
**
**--------------------------------------------------------------------------------------------------------
** Modified by:         
** Modified date:       
** Version:             
** Descriptions:        
**
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "stm32f10x.h"
#include "stm32f10x_conf.h"

#ifndef __LED_H__
#define __LED_H__
/*****����USER1�ӿ�����*****/
#define KEY1_RCC_APB2Periph  RCC_APB2Periph_GPIOA
#define KEY1_GPIO            GPIOA
#define KEY1_GPIO_Pin        GPIO_Pin_8

/*****����USER2�ӿ�����*****/
#define KEY2_RCC_APB2Periph  RCC_APB2Periph_GPIOD
#define KEY2_GPIO            GPIOD
#define KEY2_GPIO_Pin        GPIO_Pin_3

/*****����WAKEUP�ӿ�����*****/
#define KEY3_RCC_APB2Periph   RCC_APB2Periph_GPIOA
#define KEY3_GPIO            GPIOA
#define KEY3_GPIO_Pin        GPIO_Pin_0
/*********************************************************************************************************
**        �ⲿ�ӿں�������
*********************************************************************************************************/
extern void  LED_Init (void);
extern void  LED_On   (uint16_t GPIO_Pin);
extern void  LED_Off  (uint16_t GPIO_Pin);
extern void  LED_Turn (uint16_t GPIO_Pin);
extern void  Key_Init(void);
#endif
/*********************************************************************************************************
**                                        End Of File
*********************************************************************************************************/

