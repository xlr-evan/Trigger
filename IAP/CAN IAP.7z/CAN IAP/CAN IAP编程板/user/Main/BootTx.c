#include "BootTx.h"
#include "usart.h"
#include "stm32f10x.h"
#include <stdio.h>
#include <string.h>
#include "led.h"
#include "can.h"

#include "integer.h"
#include "ff.h"
#include "ffconf.h"
#include "sdcard.h"



DIR dirs;
FILINFO finfo;
FATFS fs;
FRESULT res;
FIL fsrc;
UINT br;

extern uint8_t flag;
uint16_t info[2]; 
uint8_t Bin_Buffer[1024];

/*********************************************************************************************************
** Functoin name:       delay
** Descriptions:        ��ͨ��ʱ
** input paraments:     i:������0 - 2��^3֮�����   
** output paraments:    ��    
** Returned values:     ��
*********************************************************************************************************/
void delay(uint32_t i)
{
	uint16_t j;

	for(i=i;i>0;i--)
		for(j=0;j<0x1000;j++);
}

/**************SD��Ҫ����********************/

void Boot_Send(void)
{
	const XCHAR path[]="";

	/*�����ļ�ϵͳ*/
	res = f_mount(0, &fs);
	res=f_opendir(&dirs, path);

	if (res == FR_OK){
		res = f_open(&fsrc,"Can_Updata.bin", FA_OPEN_EXISTING | FA_READ);
		if(0 != res){ /*�򿪳���*/
			printf("ERROR->OPEN FILE \r\n");
			f_close(&fsrc);
			return;
		}
		User_CANTransmit(0x01,"UPDATA",6);
		
		while(1)
		{
			if(flag==1)	//����ͷ
			{
				res = f_read(&fsrc, &info, sizeof(info), &br);
				if(0 != res){ /*������*/
					printf("ERROR->READ FILE \r\n");
					f_close(&fsrc);
					return;
				}
				printf("%x %x\r\n",info[0],info[1]);
				User_CANTransmit(0x01,(uint8_t *)info,8);
				f_lseek(&fsrc,0);
				
				flag=2;	//ͷ������
			}
			else if(flag==3)	//��ʼ����
			{
				res = f_read(&fsrc, &Bin_Buffer, 1024, &br);
				printf("br=%d\r\n",br);
				if(0 != res){ /*������*/
					printf("ERROR->READ FILE \r\n");
					f_close(&fsrc);
					flag=5;		
					return;
				}
				else{
					if(br<1024){
						if(br>0){
							User_CANSend(0x01,Bin_Buffer,br);
						}
						User_CANTransmit(0x01,"STOP",4);
						printf("Read finish\r\n");
						f_close(&fsrc);
						flag=5;		//�������
						return;
					}
					User_CANSend(0x01,Bin_Buffer,1024);
					flag=4;			//��ͣ
				}				
			}
			else if(flag == 5)		//�������
			{
				break;
			}
			LED_Turn(GPIO_Pin_7);
		}
		f_close(&fsrc);
		printf("�򿪳ɹ�\r\n");
	}
}


