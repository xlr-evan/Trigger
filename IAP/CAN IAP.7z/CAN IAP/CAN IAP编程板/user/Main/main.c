#include "usart.h"
#include "stm32f10x.h"
#include <stdio.h>
#include "led.h"
#include "can.h"
#include "BootTx.h"
#include "sdcard.h"

SD_CardInfo SDCardInfo;
unsigned char flag=0;
uint32_t TotalLen;
uint32_t Position;

/********************************************************************************************
*�������ƣ�void NVIC_Configuration(void)
*��ڲ�������
*���ڲ�������
*����˵���������ж�����
*******************************************************************************************/
void NVIC_Configuration(void)
{
//------------zp2000--------------------------------
  NVIC_InitTypeDef NVIC_InitStructure;

  /* Configure the NVIC Preemption Priority Bits */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);//�ú�������������

  NVIC_InitStructure.NVIC_IRQChannel = SDIO_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

#ifdef  VECT_TAB_RAM  
  /* Set the Vector Table base location at 0x20000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0); 
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   
#endif

}


/**************main()********************/
int main(void)
{
	//�ж�����
	NVIC_Configuration();
	
	User_CAN1Init();

	LED_Init();
	Init_Usart();
	printf("UPDATA\r\n");	
	Boot_Send();
	while(1)	   
	{		
		LED_Turn(GPIO_Pin_6);
		delay(500);		
	}
}
