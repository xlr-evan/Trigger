#ifndef __BOOTTX_H__
#define __BOOTTX_H__

#include "stm32f10x.h"

void Boot_Send(void);
void delay(unsigned int i);

#endif
