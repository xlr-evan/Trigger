#ifndef __BOOT_H
#define	__BOOT_H

#include "stm32f10x.h"

/* �������� -----------------------------------------------------------------*/
typedef  void (*pFunction)(void);


#define APP_ADDR_FLASH		0x08010000  	//Flash��Ӧ�ó�����ʼ��ַ
#define PAGE_SIZE                         (0x400)    /* 1 Kbyte */



void App_Updata(void);
void Jump_App(void);
void WriteBKP(uint16_t bkp);
uint16_t ReadBKP(void);
void Flash_WriteData(uint32_t AppAddress,uint8_t *AppBuff,uint32_t Lenth);

#endif

