#ifndef __BSP_LED_H
#define __BSP_LED_H	 

#include "stm32f10x.h"

#define LED1_ON   GPIO_ResetBits(GPIOB,GPIO_Pin_14)
#define LED1_OFF  GPIO_SetBits(GPIOB,GPIO_Pin_14)


void LED_Config(void);//LED���ƶ˿ڳ�ʼ��

#endif
