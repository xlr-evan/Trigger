#include <sys.h>
/*
 * FreeModbus Libary: BARE Demo Application
 * Copyright (C) 2006 Christian Walter <wolti@sil.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: demo.c,v 1.1 2006/08/22 21:35:13 wolti Exp $
 */

/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"


void LMTO1_Time_init();
/* ----------------------- Defines ------------------------------------------*/
//输入寄存器起始地址
#define REG_INPUT_START       0x0000
//输入寄存器数量
#define REG_INPUT_NREGS       8
//保持寄存器起始地址·
#define REG_HOLDING_START     0x0000
//保持寄存器数量
#define REG_HOLDING_NREGS     8

//ÏßÈ¦ÆðÊ¼µØÖ·
#define REG_COILS_START       0x0000
//ÏßÈ¦ÊýÁ¿
#define REG_COILS_SIZE        16



/* Private variables ---------------------------------------------------------*/
//输入寄存器内容
uint16_t usRegInputBuf[REG_INPUT_NREGS] = {0x0032,0x1001,0x1002,0x1003,0x1004,0x1005,0x1006,0x1007};
//输入寄存器起始地址
uint16_t usRegInputStart = REG_INPUT_START;

//保持寄存器内容
uint16_t usRegHoldingBuf[REG_HOLDING_NREGS] = {0x0ed6,0x3f8e,0x147b,0x400e,0x1eb8,0x4055,0x147b,0x408e};
//保持寄存器起始地址
uint16_t usRegHoldingStart = REG_HOLDING_START;

static unsigned int cnt = 0;
static unsigned int start = 0;
static unsigned int Vector = 0;
float temp = 0;

/* ----------------------- Start implementation -----------------------------*/
int main( void )
{
    sys_init();
    //LMTO1_Time_init();
    eMBInit(MB_RTU, 0x01, 0x01, 9600, MB_PAR_NONE);
    eMBEnable();
    __enable_interrupt();
    while(1)
    {
        eMBPoll();
        //temp = ((float)Vector / 4096) * 256 - 50;
        //usRegInputBuf[0]=(uint16_t)temp;
    }
}



void LMTO1_Time_init()
{

    // Configure P1.4
        P1DIR &= ~BIT4;  // input
        P1IFG &= ~BIT4; //clear
        P1IE |= BIT4;  //disable interrupt
        P1IES |= BIT4; //high to low

        // Configure Timer2_A0
        TA2CTL |= TACLR;
        TA2CCR0 = 1000;
        TA2CTL = TASSEL_1 | TAIE;      // ACLK, up mode, clear TAR, enable interrupt

            // Configure Timer1_A0
        TA1CTL |= TACLR;
        TA1CCR0 = 1500;
        TA1CTL = TASSEL_1 | TAIE;      // ACLK, up mode, clear TAR, enable interrupt

        PM5CTL0 &= ~LOCKLPM5;                    // Disable the GPIO power-on default high-impedance mode



}

/**
 * @brief  输入寄存器处理函数，可读，不可写
 * @param  pucRegBuffer  返回数据指针
 *         usAddress     寄存器起始地址
 *         usNRegs       寄存器长度
 * @retval eStatus       寄存器状态
 */
eMBErrorCode
eMBRegInputCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs )
{
 eMBErrorCode    eStatus = MB_ENOERR;
 int16_t         iRegIndex;

 //查询是否在寄存器范围
 if( ( (int16_t)usAddress >= REG_INPUT_START ) \
       && ( usAddress + usNRegs <= REG_INPUT_START + REG_INPUT_NREGS ) )
 {
   //获取操作偏移量。本次操作起始地址-输入寄存器的初始地址
   iRegIndex = ( int16_t )( usAddress - usRegInputStart );
   //逐个赋值
   while( usNRegs > 0 )
   {
     //赋值高字节
     *pucRegBuffer++ = ( uint8_t )( usRegInputBuf[iRegIndex] >> 8 );
     //赋值地字节
     *pucRegBuffer++ = ( uint8_t )( usRegInputBuf[iRegIndex] & 0xFF );
     //偏移量增加
     iRegIndex++;
     //被操作寄存器数量递减
     usNRegs--;
   }
 }
 else
 {
   //返回错误状态，无寄存器
   eStatus = MB_ENOREG;
 }

 return eStatus;
}

/**
 * @brief  保持寄存器处理函数，可读可写
 * @param  pucRegBuffer  读操作指针--返回数据指针，可操作时--输入数据指针
 *         usAddress     寄存器起始地址
 *         usNRegs       寄存器长度
 *         eMode         操作方式
 * @retval eStatus       寄存器状态
 */
eMBErrorCode
eMBRegHoldingCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs,
                eMBRegisterMode eMode )
{
 //错误状态
 eMBErrorCode    eStatus = MB_ENOERR;
 //偏移量
 int16_t         iRegIndex;

 //判断寄存器是否在范围
 if( ( (int16_t)usAddress >= REG_HOLDING_START ) \
    && ( usAddress + usNRegs <= REG_HOLDING_START + REG_HOLDING_NREGS ) )
 {
   //计算偏移量
   iRegIndex = ( int16_t )( usAddress - usRegHoldingStart );

   switch ( eMode )
   {
     //读处理函数
     case MB_REG_READ:
       while( usNRegs > 0 )
       {
         *pucRegBuffer++ = ( uint8_t )( usRegHoldingBuf[iRegIndex] >> 8 );
         *pucRegBuffer++ = ( uint8_t )( usRegHoldingBuf[iRegIndex] & 0xFF );
         iRegIndex++;
         usNRegs--;
       }
       break;

     //写处理函数
     case MB_REG_WRITE:
       while( usNRegs > 0 )
       {
         usRegHoldingBuf[iRegIndex] = *pucRegBuffer++ << 8;
         usRegHoldingBuf[iRegIndex] |= *pucRegBuffer++;
         iRegIndex++;
         usNRegs--;
       }
       break;
    }
 }
 else
 {
   //返回错误状态
   eStatus = MB_ENOREG;
 }

 return eStatus;
}
// Port 1 interrupt service routine
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(PORT1_VECTOR))) Port_1 (void)
#else
#error Compiler not supported!
#endif
  {
    switch(__even_in_range(P1IV,18))
    {
     case 0x0A:
          if(start == 0)
            {
               TA1R = 0 ;
               TA1CTL |= MC_1;
               start = 1;
            }else if(start == 1)
            {
               TA1R = 0 ;
            }
            else if(cnt == 0 && start == 2)
            {
                TA2R = 0 ;
                TA2CTL |= MC_1;
                start = 3;
                cnt++;
            }else if(start == 3)
            {
              cnt++;
              TA2R = 0 ;
            }
            break;
      default:  break;
  }
}
// Timer2_A3 Interrupt Vector (TAIV) handler
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=TIMER2_A1_VECTOR
__interrupt void TIMER2_A1_ISR(void)
#endif
{
    switch(__even_in_range(TA2IV,TA2IV_TAIFG))
    {
        case TA2IV_NONE:
            break;                               // No interrupt
        case TA2IV_TAIFG:
         TA2R = 0;
         TA2CTL &= ~MC_1;                   // stop
             start = 0;
             Vector=cnt;
            cnt = 0;


            break;
        default:
            break;
    }
}
// Timer1_A1 Interrupt Vector (TAIV) handler
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=TIMER1_A1_VECTOR
__interrupt void TIMER1_A1_ISR(void)
#endif
{
    switch(__even_in_range(TA1IV,TA1IV_TAIFG))
    {
        case TA1IV_NONE:
            break;                               // No interrupt
        case TA1IV_TAIFG:
             TA1R = 0;
             TA1CTL &= ~MC_1;                   // stop
             start = 2;
            cnt = 0;
            break;
        default:

            break;
    }
}
