/*
 * sys.h
 *
 *  Created on: 2018��4��24��
 *      Author: trigger
 */

#ifndef SYS_H_
#define SYS_H_


#include <msp430.h>

void sys_init(void);


#endif /* SYS_H_ */
