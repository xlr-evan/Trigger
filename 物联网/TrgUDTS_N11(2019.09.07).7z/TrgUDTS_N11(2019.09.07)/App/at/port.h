
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PORT_H
#define __PORT_H


/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"


/* gprs ����֡ */
typedef struct 
{
	uint8_t  RxCnt1;            // ���ռ���1
	uint8_t  RxCnt2;            // ���ռ���2
	uint8_t  AtCmdScene;        // at�������־
	uint8_t  DataRxTimeout;     // ���ڽ��ճ�ʱ
	uint8_t  keepAliveDataTxtimeout; //������ʱ��־λ
	uint8_t  RxBuff1[100];      // ���ջ�����1
	uint8_t  RxBuff2[200];      // ���ջ�����2
	uint8_t  Txbuff[16];        // ���ͻ�����
}gprsdataUART;

/* ����uart3dataRxΪȫ�ֽṹ����� */
extern gprsdataUART gprsN11data;


/** @defgroup BSP_Exported_Functions
  * @{
  */

/* GPIO */
void delayInit(void);
void delay_ms(volatile uint16_t nms);
void delay_us(volatile uint32_t nus);
void gpioInit(void);
void gprspowerON(void);
void gprspowerOFF(void);

/* TIM */
void timer3Init(void);
void time3cntEnable(uint16_t Nms);
void TIM3_IRQHandler(void);
void timer2Init(void);
void time2cntEnable(uint16_t Ns);
void time2cntDisable(void);
void TIM2_IRQHandler(void);

/* UART */
void uart3Init(void);
void uart1Init(void);
void uart1_senddata(char *fmt,...);
void uart3_senddata(char *fmt,...);
void uart3_sendHexData(uint8_t *fmt,uint8_t len);
void USART3_IRQHandler(void);
void cleanUartbuff(uint8_t buff);

void iwdgInit(void);

/**
  * @}
  */

#endif /* __PORT_H */

