
#include "str2hex.h"

/**
  * @brief  StrToHex
  * @param  None
  * @retval None
  */
uint8_t StrToHex(unsigned char * pAscii, unsigned char * pHex, int nLen)
{
	int nHexLen = nLen / 2;
	unsigned char Nibble[2] = {0};
	int i = 0;
	int j = 0;

	if (nLen%2)
	{
		return 1;
	}

	for (i = 0; i < nHexLen; i ++)
	{
		Nibble[0] = *pAscii ++;		
		Nibble[1] = *pAscii ++;
		for (j = 0; j < 2; j ++)
		{
			if (Nibble[j] <= 'F' && Nibble[j] >= 'A')
				Nibble[j] = Nibble[j] - 'A' + 10;
			else if (Nibble[j] <= 'f' && Nibble[j] >= 'a')
				Nibble[j] = Nibble[j] - 'a' + 10;
			else if (Nibble[j] >= '0' && Nibble[j] <= '9')
				Nibble [j] = Nibble[j] - '0';
			else
				return 1;//Nibble[j] = Nibble[j] - 'a' + 10;
			
		}
		pHex[i] = Nibble[0] << 4;	// Set the high nibble
		pHex[i] |= Nibble[1];	//Set the low nibble
	}
	return 0;
}

/**
  * @brief  StrToHex
  * @param  None
  * @retval None
  */
uint8_t ExtractStr(uint8_t *src,uint8_t *dest)
{
	uint8_t i = 0,len;

	/* �жϽ��յ������ݳ��� */
	if( *(src+14) != ',') return 1;
	/* �õ����ݳ��� */
	len = (*(src+12) - '0')*10 + (*(src+13) - '0');
	/* ���ݳ��Ȳ���12λ�����ݳ��ȴ��� */
	if(len != 12) return 1;

	/* ��ȡ�����ַ� */
	for(i=0;i<len;i++) dest[i] = *(src+15+i);
	
	return 0;
}



