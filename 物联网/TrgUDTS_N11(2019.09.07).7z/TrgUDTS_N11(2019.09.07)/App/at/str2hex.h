/*
 * spock_str2hex.h
 *
 *  Created on: 2018��3��14��
 *      Author: spock
 */

#ifndef STR2HEX_H_
#define STR2HEX_H_

#include "port.h"
#include <stdio.h>
#include <string.h>


uint8_t StrToHex(unsigned char * pAscii, unsigned char * pHex, int nLen);
uint8_t ExtractStr(uint8_t*src,uint8_t *dest);

#endif /* SPOCK_STR2HEX_H_ */
