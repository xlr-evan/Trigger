#ifndef __DELAY_H
#define __DELAY_H

extern void _delay_us(unsigned int time);
extern void _delay_ms(unsigned int time);

#endif
