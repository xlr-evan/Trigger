
#ifndef _MY_CAN_ISR
#define _MY_CAN_ISR 

extern void _can_init_(void);

extern void	DelayNS(unsigned long  dly);

extern void Send_Packet(unsigned char data0,unsigned char data1,unsigned char data2,unsigned char data3,unsigned char data4,unsigned char data5,unsigned char data6,unsigned char data7);

extern void _Can0_task_ISR_(void);
extern void _Uart2_task_ISR_(void);
extern void _Uart3_task_ISR_(void);
extern void _Can_Sned_Task_(void);

#define SendCommand_Upen     1
#define SendCommand_Updien     2
#define SendCommand_Dnen     3
#define SendCommand_Dndien     4
#define SendCommand_Buen     5
#define SendCommand_Budien    6
#define SendCommand_Bden     7
#define SendCommand_Bddien     8

#define SendCommand_S0    9
#define SendCommand_S1    10
#define SendCommand_S2    11
#define SendCommand_S3    12
#define SendCommand_SJJ   13
#define SendCommand_SLP   14
#define SendCommand_RST   15

#define SendCommand_MotorStop   16
#define SendCommand_MotorStop_ATest   17

#endif
