#ifndef __ADC12_h
#define __ADC12_h    1

extern void _Task_RunLed_(void);
extern void _Task_LED_State(void);

extern void ADC_init(void);

#endif
