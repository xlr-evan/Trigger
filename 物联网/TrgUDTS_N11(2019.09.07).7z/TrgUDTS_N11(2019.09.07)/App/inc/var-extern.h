#ifndef __VAR_EXT_H__ 
#define __VAR_EXT_H__

extern struct
{
	unsigned char Select;
	unsigned char Change;
}User;
extern struct
{  
   unsigned char num;
   unsigned char Counter;
   unsigned char R_Counter;
   unsigned char Loop;
   unsigned char Re_cmd[5];
   unsigned char Long_byte;  
   unsigned char ok;
}Usart0;

extern struct
{
  unsigned char min;
  unsigned char hour;
  unsigned char sec;
  unsigned char mintemp;
  unsigned char hourtemp;
}Ds1302;

extern struct
{
	unsigned char Counter;
	unsigned char Rebuf[10];
}Can0;
extern struct
{
	unsigned char Counter;
	unsigned char Rebuf[15];
}Uart3;
extern struct
{
	unsigned int Timer;
	 unsigned long Val;
	 unsigned char Sta;
	 unsigned char En;
	 unsigned char Update;
	 unsigned int  Num;
	 unsigned char twokeyval;
	 unsigned char LongKey;
}Keytask;
extern struct
{
	unsigned int Timer;
	unsigned char Mode;
	unsigned char En;
}Ring;
extern struct
{
	unsigned int Timer;
	unsigned char onoff;
	unsigned char DelayEn;
	unsigned char DelayEnTemp;
}Watch;
extern struct
{
	unsigned int ErrorTimer;
}Lcm;
extern struct
{
	unsigned char Page;
	unsigned char CursorPosition_Menu;
	unsigned char CursorPosition_SetCup;
	unsigned char Time;
	unsigned char CursorPosition_SetLD;
	unsigned char CursorPosition_SetSYS;
	unsigned char CursorPosition_SetMEM;
	unsigned char CursorPosition_SetYS;
}Disp;
extern struct
{
  unsigned char Language;
  unsigned char Time;
  unsigned char Fmq;
  unsigned char LampChair;
  unsigned char AutoCup;
  unsigned char Temp_Language;
  unsigned char Temp_Time;
  unsigned char Temp_Fmq;
  unsigned char Temp_LampChair;
  unsigned char Temp_AutoCup;
  unsigned char MemWatchRp;
  unsigned char Temp_CupRinse;
  unsigned char Temp_RinseChair;
  unsigned char CupRinse;
  unsigned char RinseChair;
  unsigned char QueShui;
  unsigned char QueShuiTemp;
  unsigned char SetMode;
}Flag;
extern struct
{
   unsigned char CupTime;
   unsigned char RiseTime;
   unsigned short CupTime_Temp;
   unsigned char RiseTime_Temp;
   unsigned char WatchPR;
   unsigned char WatchOnoff;
   unsigned char Fiber;
   unsigned char WatchPR_ok;
   unsigned char WatchOnoff_ok;
   unsigned char Fiber_ok;
   unsigned char Doctor;
}Set;
extern struct
{
   unsigned int SetVal;
   unsigned int SetValTemp;
   unsigned char Flag;
   unsigned char ReVal;
}CupTemp;
extern struct
{
	unsigned char Lamp;
	unsigned char Temp_Heat;
	unsigned char Cup;
	unsigned char Rinse;
	unsigned char Watch;
	unsigned char Yw;
	unsigned char Temp_Yw;
	unsigned char zls;
	unsigned char _Heat_;
	unsigned char jxw_sd;
	unsigned char foot;
	unsigned char rx;
	unsigned char qx;
	unsigned char hot;
	unsigned char up;
	unsigned char dn;
	unsigned char bu;
	unsigned char bd;
	unsigned char sp;
	unsigned char gpd;
	unsigned char uvc;
	unsigned char sip;
}Status;
extern struct
{
   unsigned char Hour;
   unsigned char Min;
   unsigned char Flag;
   unsigned char HourTemp;
   unsigned char MinTemp;
}Colock;
extern unsigned int Zijian_Timer;//�Լ������
extern unsigned int RestoreWaittimer;

extern struct
{
    unsigned char update;
	unsigned char Set_Pr;
	unsigned char mode;
	unsigned char s1;
	unsigned char Data;
	unsigned char Star;
	unsigned char Flag;
}apex;
 extern struct
{
	unsigned char num1;
	unsigned char num2;
	unsigned char num3;
	unsigned char num4;
	unsigned char stra;
	unsigned int timer;
	unsigned char loop;
	unsigned char mode;
	unsigned char stutas;
}pipe;
extern unsigned char Longkey_en;
extern struct
{
	unsigned char loop;
	unsigned char num;
	unsigned char work;
	unsigned int workdata;
	unsigned int standbydata[6];
	unsigned char fiber[6];
	unsigned char tiaosu[6];
	unsigned char motordir;
}qx;
extern struct
{
	unsigned char cuptime;
	unsigned char autocup;
	unsigned char cupheat;
	unsigned char cuprinse;
	unsigned char rinsetime;
	unsigned char yisheng;
	unsigned char chuchangcanshu;
	unsigned char WatchDelayEn;
	unsigned char Fiber_ok;
	unsigned char lampchair;
	unsigned char rinsechair;
	unsigned char qx_standbydata;
	unsigned char Language;
}MemFlag;
extern struct
{
	unsigned char cuptime;
	unsigned char rinse;
	unsigned char cup;
	unsigned char heat;
	unsigned char lamp;
	unsigned char xds;
	unsigned char xdq;
	unsigned char xdcommand;
	unsigned char xdwater;
	unsigned char autocup;
	unsigned char cupheat;
	unsigned char cuprinse;
	unsigned char rinsetime;
	unsigned char yisheng;
	unsigned char chuchangcanshu;
	unsigned char Fiber_ok;
	unsigned char Fiber_onoff;
	unsigned char SetMem;
	unsigned char lampchair;
	unsigned char rinsechair;
	//����
	unsigned char chaircommand;
	unsigned char hujiao;
	//��е����
	unsigned char qx_standbydata;
	unsigned char motordir;
	unsigned char qx_mode;
	unsigned char jxw_sd;
	unsigned char jxw_zd;
	unsigned char foot;
	unsigned char watch;
	unsigned char uvc;
	unsigned char sip;
}CanSendFlag;
extern unsigned char _error_;
//����λ����
extern unsigned char jxw_choose;
extern unsigned char jxw_atuo_end;
extern unsigned char ProSw;
extern unsigned char ProSwTemp;
extern unsigned char HEATER_LEDFG,Status_conmd,cup_timer;
extern unsigned int numOCM;
extern unsigned char Show_intervaltime,Show_intervaltime1,Show_intervaltime2,Show_intervaltime3,Show_Flag,Show_Flag1,Show_Flag2,Show_Flag3;
extern unsigned char JXWSdLoop;
extern  struct
{
   unsigned char Run;
   unsigned char Set;
   unsigned int Counter;
   unsigned int Time;
}LedState;
extern struct
{
    unsigned char Mode;
	unsigned int Time;
	unsigned int TimeTemp;
	unsigned char Status;
}Rinse;
extern unsigned char LockMotor_Loop;
extern unsigned char Disp_status_timer;
extern unsigned char Disp_Flag;
extern unsigned char Disp_rinse;
extern unsigned char Disp_cup;
extern unsigned long Valforanoth;
extern unsigned char twokey_flag;
extern unsigned char Key_PushNum_Temp,Key_PushNum;
extern unsigned long KeyValTempCountBit;
extern unsigned long KeyValLast;
extern unsigned char LCD_Loop;
extern unsigned char FlagDisp;
extern unsigned char DR_MODE;
extern unsigned char SPO2_PR_LCD[2];
extern unsigned char datacount1,Uart_TempData1;
extern unsigned char datacount2,Uart_TempData2;
extern unsigned char datacount3,Uart_TempData3;
extern unsigned char Flag_Send_U1,Flag_Send_U2,Flag_Send_U3;
extern unsigned char Flag_State_Send;
extern unsigned char Lock_Motor;
extern unsigned char Flag_System_Reset;
extern unsigned char Flag_JXW_State;
extern float ACCT1_Val;
extern float ACCT2_Val;
extern float ACCT3_Val;
extern float ACCT4_Val;
extern float ACCT1_Val_Temp;
extern float ACCT2_Val_Temp;
extern float Angle_Val_UP_DN;
extern float Angle_Val_BU_BD;
extern unsigned int BAROMETER_Val;
extern unsigned char Adxl_DevID;
extern unsigned int AngleTemp_X;
extern unsigned int AngleTemp_Y;
extern unsigned int AngleTemp_Z;
extern float AngleTemp_Q;
extern float AngleTemp_T;
extern float AngleTemp_K;
extern float Angle_X;
extern float Angle_Y;
extern float Angle_Z;
extern unsigned char Adxl_DevID_2;
extern unsigned int AngleTemp_X_2;
extern unsigned int AngleTemp_Y_2;
extern unsigned int AngleTemp_Z_2;
extern float AngleTemp_Q_2;
extern float AngleTemp_T_2;
extern float AngleTemp_K_2;
extern float Angle_X_2;
extern float Angle_Y_2;
extern float Angle_Z_2;
extern unsigned char Flag_SetState,Flag_AutoTest;
extern unsigned int AutoTest_Counter;
extern unsigned char Loop_AutoTest;
extern unsigned char AutoTest_Interval_Time;
extern unsigned char Auto_Pos_EN;
extern unsigned char Fault_Request;
extern unsigned char Flag_AutoTest_End;

#endif
