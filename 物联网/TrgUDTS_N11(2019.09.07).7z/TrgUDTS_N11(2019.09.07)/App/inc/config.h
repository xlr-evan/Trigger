
#ifndef __CONFIG_H__ 
#define __CONFIG_H__

#include <stdio.h>
#include <math.h>
#include "stm32f10x.h"
typedef unsigned char  uint8;                   /* defined for unsigned 8-bits integer variable 	�޷���8λ���ͱ���  */
typedef signed   char  int8;                    /* defined for signed 8-bits integer variable		�з���8λ���ͱ���  */
typedef unsigned short uint16;                  /* defined for unsigned 16-bits integer variable 	�޷���16λ���ͱ��� */
typedef signed   short int16;                   /* defined for signed 16-bits integer variable 		�з���16λ���ͱ��� */
typedef unsigned int   uint32;                  /* defined for unsigned 32-bits integer variable 	�޷���32λ���ͱ��� */
typedef signed   int   int32;                   /* defined for signed 32-bits integer variable 		�з���32λ���ͱ��� */
typedef float          fp32;                    /* single precision floating point variable (32bits) �����ȸ�������32λ���ȣ� */
typedef double         fp64;                    /* double precision floating point variable (64bits) ˫���ȸ�������64λ���ȣ� */

//ϵͳͷ�ļ�
//ͷ�ļ��ĵ���


//�Զ����ͷ�ļ�
//#include "my_can.h"
#include "Adxl345.h"
//#include "key4_6.h"
//#include "ring.h"

//�Զ���ͷ�ļ�
#include "isr_can_task.h"
#include "Sysinit.h"
//#include "Task_uart0.h"
//#include "lcm.h"
//#include"pipe.h"
//#include"work.h"
//#include "memory.h"
#include "Adc12.h"
#include "delay.h"
#include "at.h"

extern void Timer0A_ISR(void);
//extern void _Task_colock_(void);
extern void ISR_UART0(void);
extern void wdogInit(u8 prer,u16 rlr);
extern void wdogFeed(void);
//��ʱ������   8m���� 
#define _1S_       25000000UL   
#define _500MS_    12500000UL 
#define _200MS_    5000000UL  
#define _100MS_    2500000UL
#define _50MS_     1250000UL
#define _20MS_     500000UL
#define _10MS_     250000UL
/*����ID*/
#define  	host_id    0xe0
#define 	SCALER     2
#define 	MOTOR     1
#define  	TURBINE    0

#define A_ledOFF      GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET); 
#define A_ledON	      GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_RESET);
#define B_ledOFF      GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_SET); 
#define B_ledON	      GPIO_WriteBit(GPIOA, GPIO_Pin_5, Bit_RESET);
#define C_ledOFF      GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_SET); 
#define C_ledON 	  	GPIO_WriteBit(GPIOA, GPIO_Pin_6, Bit_RESET);
#define SETLED_ON     GPIO_WriteBit(GPIOC, GPIO_Pin_4, Bit_RESET);
#define SETLED_OFF	  GPIO_WriteBit(GPIOC, GPIO_Pin_4, Bit_SET);
#define CHAIRLED_ON		GPIO_WriteBit(GPIOC, GPIO_Pin_5, Bit_RESET);
#define CHAIRLED_OFF	GPIO_WriteBit(GPIOC, GPIO_Pin_5, Bit_SET);
#define HEATLED_ON    GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_RESET);
#define HEATLED_OFF	  GPIO_WriteBit(GPIOA, GPIO_Pin_7, Bit_SET);

#endif
/*********************************************************************************************************
**                            End Of File
********************************************************************************************************/
