#ifndef __VAR_H__ 
#define __VAR_H__
          

struct
{
	unsigned char Select;
	unsigned char Change;
}User={0,0};
struct
{
  unsigned char min;
  unsigned char hour;
  unsigned char sec;
  unsigned char mintemp;
  unsigned char hourtemp;
}Ds1302 = {0x12,0x12,0x10,0,0};

struct
{ 
   unsigned char num;
   unsigned char Counter;
   unsigned char R_Counter;
   unsigned char Loop;
   unsigned char Re_cmd[5];
   unsigned char Long_byte; 
   unsigned char ok;
}Usart0;

struct
{
	unsigned char Counter;
	unsigned char Rebuf[10];
}Can0;
struct
{
	unsigned char Counter;
	unsigned char Rebuf[15];
}Uart3;
struct
{
     unsigned int Timer;
	 unsigned char Mode;
	 unsigned char En;
}Ring ={0,0,1};
//����ɨ�账������
struct
{
  	 unsigned int Timer;
	 unsigned long Val;
	 unsigned char Sta;
	 unsigned char En;
	 unsigned char Update;
	 unsigned int Num;
	 unsigned char twokeyval;
	 unsigned char LongKey;
}Keytask = {0,0,0,1,0,0,0};
//��Ƭ�ƴ�������
struct
{
     unsigned int Timer;
	 unsigned char onoff;
	 unsigned char DelayEn;
	 unsigned char DelayEnTemp;
}Watch = {0,0,0,0};
//Һ������������
struct
{
     unsigned int ErrorTimer;
}Lcm;
struct
{
   unsigned char Page;
   unsigned char CursorPosition_Menu;
   unsigned char CursorPosition_SetCup;
   unsigned char Time;
   unsigned char CursorPosition_SetLD;
   unsigned char CursorPosition_SetSYS;
   unsigned char CursorPosition_SetMEM;
   unsigned char CursorPosition_SetYS;
}Disp;
struct
{
  unsigned char Language;
  unsigned char Time;
  unsigned char Fmq;
  unsigned char LampChair;
  unsigned char AutoCup;
  unsigned char Temp_Language;
  unsigned char Temp_Time;
  unsigned char Temp_Fmq;
  unsigned char Temp_LampChair;
  unsigned char Temp_AutoCup;
  unsigned char MemWatchRp;
  unsigned char Temp_CupRinse;
  unsigned char Temp_RinseChair;
  unsigned char CupRinse;
  unsigned char RinseChair;
  unsigned char QueShui;
  unsigned char QueShuiTemp;
  unsigned char SetMode;
}Flag = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
struct
{
   unsigned char CupTime;
   unsigned char RiseTime;
   unsigned short CupTime_Temp;
   unsigned char RiseTime_Temp;
   unsigned char WatchPR;
   unsigned char WatchOnoff;
   unsigned char Fiber;
   unsigned char WatchPR_ok;
   unsigned char WatchOnoff_ok;
   unsigned char Fiber_ok;
   unsigned char Doctor;
}Set={5,1,1,1,0,0,5,0,0,0,0};
struct
{
   unsigned int SetVal;
   unsigned int SetValTemp;
   unsigned char Flag;
   unsigned char ReVal;
}CupTemp={20,20,0,0};

struct
{
   unsigned char Hour;
   unsigned char Min;
   unsigned char Flag;
   unsigned char HourTemp;
   unsigned char MinTemp;
}Colock;
unsigned int Zijian_Timer = 0;
unsigned int RestoreWaittimer = 0;
//num=1~4��ʾ4·��е
struct
{
    unsigned char update;
	unsigned char Set_Pr;
	unsigned char mode;
	unsigned char s1;
	unsigned char Data;
	unsigned char Star;
	unsigned char Flag;
}apex;
unsigned char Longkey_en = 0;
struct
{
    unsigned char loop;
	unsigned char num;
	unsigned char work;
	unsigned int workdata;
	unsigned int standbydata[6];
	unsigned char fiber[6];
	unsigned char tiaosu[6];
	unsigned char motordir;
}qx = {0,0,0,50,100,100,100,100,100,800,1,1,1,1,1,1,1,1,1,1,1,1,0};
struct
{
     unsigned char cuptime;
	 unsigned char autocup;
	 unsigned char cupheat;
	 unsigned char cuprinse;
	 unsigned char rinsetime;
	 unsigned char yisheng;
	 unsigned char chuchangcanshu;
	 unsigned char WatchDelayEn;
	 unsigned char Fiber_ok;
	 unsigned char lampchair;
	 unsigned char rinsechair;
	 unsigned char qx_standbydata;
	 unsigned char Language;
}MemFlag;
struct
{
	unsigned char cuptime;
	unsigned char rinse;
	unsigned char cup;
	unsigned char heat;
	unsigned char lamp;
	unsigned char xds;
	unsigned char xdq;
	unsigned char xdcommand;
	unsigned char xdwater;
	unsigned char autocup;
	unsigned char cupheat;
	unsigned char cuprinse;
	unsigned char rinsetime;
	unsigned char yisheng;
	unsigned char chuchangcanshu;
	unsigned char Fiber_ok;
	unsigned char Fiber_onoff;
	unsigned char SetMem;
	unsigned char lampchair;
	unsigned char rinsechair;
	//����
	unsigned char chaircommand;
	unsigned char hujiao;
	//��е����
	unsigned char qx_standbydata;
	//����ת����
	unsigned char motordir;
	//���ٲ��ɵ�ѡ��
	unsigned char qx_mode;
	unsigned char jxw_sd;
	unsigned char jxw_zd;
	unsigned char foot;
	unsigned char watch;
	unsigned char uvc;
	unsigned char sip;
}CanSendFlag;
unsigned char _error_ = 0;
struct
{
	unsigned char Lamp;
	unsigned char Temp_Heat;
	unsigned char Cup;
	unsigned char Rinse;
	unsigned char Watch;
	unsigned char Yw;
	unsigned char Temp_Yw;
	unsigned char zls;
	unsigned char _Heat_;
	unsigned char jxw_sd;
	unsigned char foot;
	unsigned char rx;
	unsigned char qx;
	unsigned char hot;
	unsigned char up;
	unsigned char dn;
	unsigned char bu;
	unsigned char bd;
	unsigned char sp;
	unsigned char gpd;
	unsigned char uvc;
	unsigned char sip;
}Status;
//����λ����
unsigned char jxw_choose = 0;
unsigned char jxw_atuo_end = 0;

struct
{
	unsigned char num1;
	unsigned char num2;
	unsigned char num3;
	unsigned char num4;
	unsigned char stra;
	unsigned int timer;
	unsigned char loop;
	unsigned char mode;
	unsigned char stutas;
}pipe;
unsigned char ProSw = 0;//��������״̬
unsigned char ProSwTemp;
unsigned char HEATER_LEDFG,Status_conmd,cup_timer;
unsigned int numOCM;
unsigned char Show_intervaltime,Show_intervaltime1,Show_intervaltime2,Show_intervaltime3,Show_Flag,Show_Flag1,Show_Flag2,Show_Flag3=0;
unsigned char JXWSdLoop=0;
struct
{
   unsigned char Run;
   unsigned char Set;
   unsigned int Counter;
   unsigned int Time;
}LedState;
unsigned char LockMotor_Loop=0;
struct
{
    unsigned char Mode;
	unsigned int Time;
	unsigned int TimeTemp;
	unsigned char Status;
}Rinse;
unsigned char Disp_status_timer;
unsigned char Disp_Flag;
unsigned char Disp_rinse = 60;	  //��ʾʱ���ʼֵ
unsigned char Disp_cup = 5;		//��ʾʱ���ʼֵ
unsigned long Valforanoth;
unsigned char twokey_flag = 0;
unsigned char Key_PushNum_Temp = 0,Key_PushNum = 0;
unsigned long KeyValTempCountBit = 0;
unsigned long KeyValLast = 0;
unsigned char LCD_Loop = 0;
unsigned char FlagDisp = 0;
unsigned char DR_MODE = 1;
unsigned char SPO2_PR_LCD[2];
unsigned char datacount1,Uart_TempData1;
unsigned char datacount2,Uart_TempData2;
unsigned char datacount3,Uart_TempData3;
unsigned char Flag_Send_U1,Flag_Send_U2,Flag_Send_U3;
unsigned char Flag_State_Send = 0;
unsigned char Lock_Motor = 0;
unsigned char Flag_System_Reset = 0;
unsigned char Flag_JXW_State = 0;
float ACCT1_Val = 0;
float ACCT2_Val = 0;
float ACCT3_Val = 0;
float ACCT4_Val = 0;
float ACCT1_Val_Temp = 0;
float ACCT2_Val_Temp = 0;
float Angle_Val_UP_DN ;
float Angle_Val_BU_BD;
unsigned int BAROMETER_Val = 0;
unsigned char Adxl_DevID;
unsigned int AngleTemp_X;
unsigned int AngleTemp_Y;
unsigned int AngleTemp_Z;
float AngleTemp_Q;
float AngleTemp_T;
float AngleTemp_K;
float Angle_X;
float Angle_Y;
float Angle_Z;
unsigned char Adxl_DevID_2;
unsigned int AngleTemp_X_2;
unsigned int AngleTemp_Y_2;
unsigned int AngleTemp_Z_2;
float AngleTemp_Q_2;
float AngleTemp_T_2;
float AngleTemp_K_2;
float Angle_X_2;
float Angle_Y_2;
float Angle_Z_2;
unsigned char Flag_SetState,Flag_AutoTest = 0;
unsigned int AutoTest_Counter = 0;
unsigned char Loop_AutoTest = 0;
unsigned char AutoTest_Interval_Time = 0;
unsigned char Auto_Pos_EN = 0;
unsigned char Fault_Request = 0;
unsigned char Flag_AutoTest_End = 0;

#endif
