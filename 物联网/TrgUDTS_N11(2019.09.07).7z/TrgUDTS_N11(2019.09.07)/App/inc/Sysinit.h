#ifndef __SYSINIT_H__ 
#define __SYSINIT_H__

extern void _Gpio_init_(void);
extern void _Sys_init_(void);

extern void _timer_init_(void);
extern void _LCD_init(void);
#endif

