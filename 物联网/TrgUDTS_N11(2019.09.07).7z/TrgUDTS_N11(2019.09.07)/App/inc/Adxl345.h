#ifndef __Adxl345_H__ 
#define __Adxl345_H__  
extern void Adxl345_Init(void); 
extern unsigned char Adxl345_Read(unsigned char ReadAddr);
extern unsigned int Adxl345_Read_Word(unsigned char StartAddr);
extern void Adxl345_Write(unsigned char WriteAddr,unsigned char DataToWrite);
extern void Adxl345_Write_Word(unsigned char StartAddr,unsigned int dat);
extern void Task_Angle_Val(void);

extern void Adxl345_Init_2(void); 
extern unsigned char Adxl345_Read_2(unsigned char ReadAddr);
extern unsigned int Adxl345_Read_Word_2(unsigned char StartAddr);
extern void Adxl345_Write_2(unsigned char WriteAddr,unsigned char DataToWrite);
extern void Adxl345_Write_Word_2(unsigned char StartAddr,unsigned int dat);
extern void Task_Angle_Val_2(void);

#endif

