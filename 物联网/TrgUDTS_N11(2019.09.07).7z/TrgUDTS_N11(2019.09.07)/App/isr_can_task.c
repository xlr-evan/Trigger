
#include "config.h"
#include "var-extern.h"

#define CAN_SEND_DELAY 80
#define K_ACCT_Volt 0.892
#define PI 3.14159265

extern __IO u16 ADC_ConvertedValue[2];	
unsigned char state1,state2,state3,state4,state5,state6,state7,state8,state9,state10,state11,state12,state13,state14,state_temp;

void _can_init_(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	CAN_InitTypeDef        CAN_InitStructure;
 	CAN_FilterInitTypeDef  CAN_FilterInitStructure;

	NVIC_InitTypeDef  NVIC_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);//ʹ��PORTAʱ��	                   											 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);//ʹ��CAN1ʱ��	

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//��������
	GPIO_Init(GPIOA, &GPIO_InitStructure);		//��ʼ��IO
   
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//��������
	GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��IO
	  
 	//CAN��Ԫ����
 	CAN_InitStructure.CAN_TTCM=DISABLE;	//��ʱ�䴥��ͨ��ģʽ  //
 	CAN_InitStructure.CAN_ABOM=DISABLE;	//�����Զ����߹���	 //
	CAN_InitStructure.CAN_AWUM=DISABLE;	//˯��ģʽͨ����������(���CAN->MCR��SLEEPλ)//
	CAN_InitStructure.CAN_NART=ENABLE;	//��ֹ�����Զ����� //
	CAN_InitStructure.CAN_RFLM=DISABLE;	//���Ĳ�����,�µĸ��Ǿɵ� // 
	CAN_InitStructure.CAN_TXFP=DISABLE;	//���ȼ��ɱ��ı�ʶ������ //
	CAN_InitStructure.CAN_Mode= 0;	  //ģʽ���ã� mode:0,��ͨģʽ;1,�ػ�ģʽ; //
  	//���ò�����
	//	CAN_Mode_Init(CAN_SJW_1tq,CAN_BS2_7tq,CAN_BS1_8tq,5,mode);
	//125k
	CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;				//����ͬ����Ծ����(Tsjw)Ϊtsjw+1��ʱ�䵥λ  CAN_SJW_1tq	 CAN_SJW_2tq CAN_SJW_3tq CAN_SJW_4tq
	CAN_InitStructure.CAN_BS1=CAN_BS1_13tq; //Tbs1=tbs1+1��ʱ�䵥λCAN_BS1_1tq ~CAN_BS1_16tq
	CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;//Tbs2=tbs2+1��ʱ�䵥λCAN_BS2_1tq ~	CAN_BS2_8tq
	CAN_InitStructure.CAN_Prescaler=18;            //��Ƶϵ��(Fdiv)Ϊbrp+1	//
	CAN_Init(CAN1, &CAN_InitStructure);            // ��ʼ��CAN1 

 	CAN_FilterInitStructure.CAN_FilterNumber=0;	  //������0
 	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 
	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit; //32λ 

	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;////32λID ԭ��Ϊ0x0000	 ����260��id��Ϊ0x13  
	CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;//32λMASK	ԭ��Ϊ0x0000 ����260��id��Ϊ0x13
	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;//������0������FIFO0
 	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; //���������0

	CAN_FilterInit(&CAN_FilterInitStructure);//�˲�����ʼ��
	
	CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);//FIFO0��Ϣ�Һ��ж�����.		    
  
	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;     // �����ȼ�Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;            // �����ȼ�Ϊ0
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}
void Send_Packet(unsigned char data0,unsigned char data1,unsigned char data2,unsigned char data3,unsigned char data4,unsigned char data5,unsigned char data6,unsigned char data7)
{
	u16 i=0;
	u8 mbox=0;
	CanTxMsg TxMessage;
	
	TxMessage.StdId=0x00000718;					 // ��׼��ʶ��Ϊ0
	TxMessage.ExtId=0x00000718;				 // ������չ��ʾ����29λ��
	TxMessage.IDE=0;			 // ʹ����չ��ʶ��
	TxMessage.RTR=0;		 // ��Ϣ����Ϊ����֡��һ֡8λ
	TxMessage.DLC=8;	
	TxMessage.Data[0]=data0;				 // ��һ֡��Ϣ 
	TxMessage.Data[1]=data1; 
	TxMessage.Data[2]=data2;
	TxMessage.Data[3]=data3;  
	TxMessage.Data[4]=data4;
	TxMessage.Data[5]=data5; 
	TxMessage.Data[6]=data6;
	TxMessage.Data[7]=data7;       
	mbox= CAN_Transmit(CAN1, &TxMessage);  
	
	i=0;
	while((CAN_TransmitStatus(CAN1, mbox)!= CAN_TxStatus_Ok)&&(i<0XFFF))i++;	//�ȴ����ͽ���	
}

/*void USART1_IRQHandler(void)
{		
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
	{	
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);	
		Uart_TempData1 = USART_ReceiveData(USART1);
		if(Uart_TempData1!=0xed)
		{
			Can0.Rebuf[datacount1] = Uart_TempData1;
			datacount1++;
		}
		else
		{
			Can0.Rebuf[datacount1] = Uart_TempData1;
			datacount1 = 0;
			//_Can0_task_ISR_();		
		}
	}		
}
void USART3_IRQHandler(void)
{		
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
	{	
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);	
		Uart_TempData3 = USART_ReceiveData(USART3);
		if(Uart_TempData3!=0xed)
		{
			Uart3.Rebuf[datacount3] = Uart_TempData3;
			datacount3++;
		}
		else
		{
			Uart3.Rebuf[datacount3] = Uart_TempData3;
			datacount3 = 0;
			_Uart3_task_ISR_();
		}
	}		
}*/
CanRxMsg RxMessage;
void USB_LP_CAN1_RX0_IRQHandler(void)
{	
	int i=0;
	
	CAN_Receive(CAN1, 0, &RxMessage);
	for(i=0;i<8;i++)
	{
		Can0.Rebuf[i]=RxMessage.Data[i];
	} 
	_Can0_task_ISR_();
}
void _Can0_task_ISR_(void)
{
	unsigned char i;
	
	if(Can0.Rebuf[1]==0xe3)
	{
		switch(Can0.Rebuf[2])
		{
			case 3:
				switch (Can0.Rebuf[4])
				{
					case 0xf0: 	Status.up = 0;Status.dn = 0;Status.bu = 0;Status.bd = 0;break;
					case 0xf1: 	Status.up = 1;Status.dn = 0;Status.bu = 0;Status.bd = 0;break;
					case 0xf2: 	Status.up = 0;Status.dn = 1;Status.bu = 0;Status.bd = 0;break;
					case 0xf4:	Status.up = 0;Status.dn = 0;Status.bu = 1;Status.bd = 0;break;
					case 0xf5: 	Status.up = 1;Status.dn = 0;Status.bu = 1;Status.bd = 0;break;
					case 0xf6:	Status.up = 0;Status.dn = 1;Status.bu = 1;Status.bd = 0;break;
					case 0xf8: 	Status.up = 0;Status.dn = 0;Status.bu = 0;Status.bd = 1;break;
					case 0xf9: 	Status.up = 1;Status.dn = 0;Status.bu = 0;Status.bd = 1;break;
					case 0xfa: 	Status.up = 0;Status.dn = 1;Status.bu = 0;Status.bd = 1;break;	
				}
				Status.Yw = Can0.Rebuf[3];
				switch (Status.Yw)
				{
					case 0x1: Status.sp = 1;break;
					case 0xff: Status.sp = 0;break;
				}
				break;
			case 6:
				Status.Cup = (Can0.Rebuf[3]&0x02)>>1;
				Status.Rinse = (Can0.Rebuf[3]&0x04)>>2;
				Status.Lamp = (Can0.Rebuf[3]&0x08)>>3;
				Status.gpd = (Can0.Rebuf[3]&0x01);
				Status._Heat_ = Can0.Rebuf[5];//����3��״̬0 1 2

				CupTemp.ReVal = Can0.Rebuf[4];			
				Disp_cup =  Can0.Rebuf[6];
				if(Can0.Rebuf[7]&0x80)
					Status.rx = 1;
				else  
					Status.rx = 0;
				if(Can0.Rebuf[7]&0x40 )
					Status.qx = 1;
				else  
					Status.qx = 0;
				Disp_rinse =  Can0.Rebuf[7]&0x3F;
				Status_conmd = 1;
				break;
			case 8:
				Set.Doctor=Can0.Rebuf[3];
				switch(Set.Doctor)
				{
				    case 0:
					    A_ledON;
					    B_ledOFF;
					    C_ledOFF;
					    break;
				    case 1:
					    A_ledOFF;
				    	B_ledON;
					    C_ledOFF;
					    break;
				    case 2:
					    A_ledOFF;
					    B_ledOFF;
					    C_ledON;
					    break;
				}
				break;
			
			default:Can0.Rebuf[2]=0;
		}
	}
	else if(Can0.Rebuf[0]==0xea)
	{
		Status.Yw = Can0.Rebuf[2];
		switch (Status.Yw)
		{
			case 0xf0: 	Status.up = 0;Status.dn = 0;Status.bu = 0;Status.bd = 0;break;
			case 0xf1: 	Status.up = 1;Status.dn = 0;Status.bu = 0;Status.bd = 0;break;
			case 0xf2: 	Status.up = 0;Status.dn = 1;Status.bu = 0;Status.bd = 0;break;
			case 0xf4:	Status.up = 0;Status.dn = 0;Status.bu = 1;Status.bd = 0;break;
			case 0xf5: 	Status.up = 1;Status.dn = 0;Status.bu = 1;Status.bd = 0;break;
			case 0xf6:	Status.up = 0;Status.dn = 1;Status.bu = 1;Status.bd = 0;break;
			case 0xf8: 	Status.up = 0;Status.dn = 0;Status.bu = 0;Status.bd = 1;break;
			case 0xf9: 	Status.up = 1;Status.dn = 0;Status.bu = 0;Status.bd = 1;break;
			case 0xfa: 	Status.up = 0;Status.dn = 1;Status.bu = 0;Status.bd = 1;break;					
		}					
		Status.gpd = (Can0.Rebuf[6]&0x10)>>4;
		Status.Cup = (Can0.Rebuf[6]&0x20)>>5;
		Status.Rinse = (Can0.Rebuf[6]&0x40)>>6;
		Status.Lamp = (Can0.Rebuf[6]&0x80)>>7;			
		Status._Heat_ = Can0.Rebuf[6]&0x0f;//����3��״̬0 1 2				
		CupTemp.ReVal = Can0.Rebuf[3];				

		Disp_cup =  Can0.Rebuf[4];	
		if((Can0.Rebuf[5]&0x80 ))
			Status.rx = 1;
		else  
			Status.rx = 0;
		if((Can0.Rebuf[5]&0x40 ))
			Status.qx = 1;
		else  
			Status.qx = 0;
		Disp_rinse =  Can0.Rebuf[5]&0x3F;	
		Status.sp = Can0.Rebuf[7]&0x01;
		Auto_Pos_EN = (Can0.Rebuf[7]&0x02)>>1;
		Set.Doctor = Can0.Rebuf[1]&0x03;
		Flag_JXW_State = Can0.Rebuf[1];
		
		if((Can0.Rebuf[1]==0xcd)&&(Can0.Rebuf[2]==0xdc)&&(Can0.Rebuf[3]==0xf0)&&(Can0.Rebuf[4]==0x01)&&(Can0.Rebuf[7]==0xed))
		{
			Fault_Request = 1; 
		}
		if((Can0.Rebuf[1]==0xcd)&&(Can0.Rebuf[2]==0xdc)&&(Can0.Rebuf[3]==0xfe)&&(Can0.Rebuf[4]==0xff)&&(Can0.Rebuf[7]==0xed))
		{
			Flag_AutoTest_End = 1;
		}
	}
	//����������
	for(i=0;i<8;i++)
	{
		Can0.Rebuf[i] = 0;
	}
}
/*void _Uart3_task_ISR_(void)
{
	unsigned char i;
	
	if((Uart3.Rebuf[0]==0xcd)&&(Uart3.Rebuf[1]==0xdc))
	{
		switch(Uart3.Rebuf[2])
		{
			case 0x06: 				
				break;
			case 0x16: 
				if((Uart3.Rebuf[3]==1)&&(Uart3.Rebuf[4]==1))
					Flag_State_Send = 1;
				break;
			case 0x09: 				
				break;
			case 0xa1: 
				switch(Uart3.Rebuf[3])
				{
					case 0x01: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_Upen;
						else
							CanSendFlag.chaircommand = SendCommand_Updien;
						break;
					case 0x02: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_Dnen;
						else
							CanSendFlag.chaircommand = SendCommand_Dndien;
						break;
					case 0x03: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_Buen;
						else
							CanSendFlag.chaircommand = SendCommand_Budien;
						break;
					case 0x04: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_Bden;
						else
							CanSendFlag.chaircommand = SendCommand_Bddien;
						break;
					case 0x10: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_S0;
						else
							CanSendFlag.chaircommand = SendCommand_MotorStop;
						break;
					case 0x11: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_S1;
						else
							CanSendFlag.chaircommand = SendCommand_MotorStop;
						break;
					case 0x12: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_S2;
						else
							CanSendFlag.chaircommand = SendCommand_MotorStop;
						break;
					case 0x13: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_S3;
						else
							CanSendFlag.chaircommand = SendCommand_MotorStop;
						break;
					case 0x14: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_SLP;
						else
							CanSendFlag.chaircommand = SendCommand_MotorStop;
						break;
					case 0x1a: 
						if(Uart3.Rebuf[4]==1)
							CanSendFlag.chaircommand = SendCommand_MotorStop;
						break;
					case 0x0a: 
						if(Uart3.Rebuf[4]==1)
							Lock_Motor = 0xff;
						else
							Lock_Motor = 1;
						break;
					default:break;
				}
				break;
			case 0xb1: 
				switch(Uart3.Rebuf[3])
				{
					case 0x01: 
						if(Uart3.Rebuf[4])
						{
							if(!Status._Heat_)
								CanSendFlag.heat = 1;
						}
						else
						{
							if(Status._Heat_)
								CanSendFlag.heat = 1;
						}
						break;
					case 0x02:
						if(Uart3.Rebuf[4])
						{
							if(!Status.Rinse)
								CanSendFlag.rinse = 1;
						}
						else
						{
							if(Status.Rinse)
								CanSendFlag.rinse = 1;
						}
						break;
					case 0x03:
						if(Uart3.Rebuf[4])
						{
							if(!Status.Cup)
								CanSendFlag.cup = 1;
						}
						else
						{
							if(Status.Cup)
								CanSendFlag.cup = 1;
						}
						break;
					case 0x04:
						if(Uart3.Rebuf[4])
						{
							if(!Status.Lamp)
								CanSendFlag.lamp = 1;
						}
						else
						{
							if(Status.Lamp)
								CanSendFlag.lamp = 1;
						}
						break;
					case 0x05:
						if(Uart3.Rebuf[4])
						{
							if(!Status.gpd)
								CanSendFlag.watch = 1;
						}
						else
						{
							if(Status.gpd)
								CanSendFlag.watch = 1;
						}
						break;
					case 0x06:
						if(Uart3.Rebuf[4])
						{
							if(!Status.uvc)
								CanSendFlag.uvc = 1;
						}
						else
						{
							if(Status.uvc)
								CanSendFlag.uvc = 1;
						}
						break;
					case 0x07:
						if(Uart3.Rebuf[4])
						{
							if(!Status.sip)
								CanSendFlag.sip = 1;
						}
						else
						{
							if(Status.sip)
								CanSendFlag.sip = 1;
						}
						break;
					case 0x0a:
						CanSendFlag.yisheng = 1;
						Set.Doctor = 0;
						break;
					case 0x0b:
						CanSendFlag.yisheng = 1;
						Set.Doctor = 1;
						break;
					case 0x0c:
						CanSendFlag.yisheng = 1;
						Set.Doctor = 2;
						break;
					default:break;
				}
				break;
			case 0xe1: 
				if((Uart3.Rebuf[3]==1)&&(Uart3.Rebuf[4]==1))
				{
					CanSendFlag.jxw_sd = 1;
					Status.jxw_sd = 1;
				}
				break;
			case 0x4d:
				if(Uart3.Rebuf[9])
				{
					Set.CupTime_Temp = Uart3.Rebuf[9]*20;
					if(Set.CupTime_Temp>1200)
						Set.CupTime_Temp = 1200;
					CanSendFlag.cuptime = 2;
				}
				if(Uart3.Rebuf[10])
				{
					if((Uart3.Rebuf[10]>0)&&(Uart3.Rebuf[10]<10))
						Rinse.Mode = 1;
					if((Uart3.Rebuf[10]>9)&&(Uart3.Rebuf[10]<20))
						Rinse.Mode = 2;
					if((Uart3.Rebuf[10]>19)&&(Uart3.Rebuf[10]<30))
						Rinse.Mode = 3;
					if((Uart3.Rebuf[10]>29)&&(Uart3.Rebuf[10]<60))
						Rinse.Mode = 4;
					if(Uart3.Rebuf[10]>59)
						Rinse.Mode = 5;
					CanSendFlag.rinse = 2;
				}
				if(Uart3.Rebuf[11])
				{
					AutoTest_Interval_Time = Uart3.Rebuf[11];
					if((AutoTest_Interval_Time<1)|(AutoTest_Interval_Time>100))
						AutoTest_Interval_Time=1;
				}
				break;
			case 0x5e:
				switch(Uart3.Rebuf[3])
				{
					case 0x01:
						if(Uart3.Rebuf[4])
						{
							Flag_SetState = 1;
						}
						else
						{
							Flag_SetState = 0;
						}
						break;
					case 0x10:
						if(Uart3.Rebuf[4])
						{
							Flag_AutoTest = 1;
						}
						else
						{
							Flag_AutoTest = 0;
							Loop_AutoTest = 0;
							CanSendFlag.chaircommand = SendCommand_MotorStop_ATest;		
						}
						break;
					default:break;
				}
				break;	
			case 0xf1:
				if((Uart3.Rebuf[3]==1)&&(Uart3.Rebuf[4]==1))
					Flag_System_Reset = 1;
				break;
			default:break;
		}
	}
	//����������
	for(i=0;i<6;i++)
	{
		Uart3.Rebuf[i] = 0;
	} 
}*/

//CAN�������ݷ��ͺ���
void _Can_Sned_Task_(void)
{		
	/*if(CanSendFlag.cuptime) 	  
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.cuptime)
		{
			Send_Packet(0xe3,0xe0,0x26,0x01,Set.CupTime_Temp/20,CanSendFlag.cuptime,0x00,0xed);
			CanSendFlag.cuptime = 0;
		}		
	}
	if(CanSendFlag.rinse)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.rinse)
		{
			Send_Packet(0xe3,0xe0,0x20,Rinse.Mode,CanSendFlag.rinse,0x00,0x00,0xed);
			CanSendFlag.rinse = 0;
		}	
	}
	if(CanSendFlag.cup == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.cup == 1)
		{
			CanSendFlag.cup = 0;
			Send_Packet(0xe3,0xe0,0x21,0x00,0x00,0x00,0x00,0xed);
		}	
	}
	if(CanSendFlag.heat == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.heat == 1)
		{
			CanSendFlag.heat = 0;
			Send_Packet(0xe3,0xe0,0x22,0x00,0x00,0x00,0x00,0xed);
		}		
	}
	if(CanSendFlag.lamp == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.lamp == 1)
		{
			CanSendFlag.lamp = 0;
			Send_Packet(0xe3,0xe0,0x23,0x00,0x00,0x00,0x00,0xed);
		}	
	}
	if(CanSendFlag.yisheng == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.yisheng == 1)
		{
			CanSendFlag.yisheng = 0;
			Send_Packet(0xe3,0xe0,0xf0,Set.Doctor,0x00,0x00,0x00,0xed);
		}	
	}
	if(CanSendFlag.SetMem == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.SetMem == 1)
		{
			CanSendFlag.SetMem = 0;
			Send_Packet(0xe3,0xe0,0x37,Disp.CursorPosition_SetMEM+1,0x00,0x00,0x00,0xed);
		}	
	}
	if(CanSendFlag.chaircommand)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.chaircommand)
		{
			Send_Packet(0xe3,0xe0,0x31,CanSendFlag.chaircommand,0x00,0x00,0x00,0xed);
			CanSendFlag.chaircommand = 0;
		}	
	}*/
	if (CanSendFlag.jxw_sd == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if (CanSendFlag.jxw_sd == 1)
		{
			CanSendFlag.jxw_sd = 0;
			Send_Packet(0xe3,0xe0,0x38,0x02,Status.jxw_sd,0x00,0x00,0xed);
		}		
	} 
	/*if(CanSendFlag.watch == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.watch == 1)
		{
			CanSendFlag.watch = 0;
			Send_Packet(0xe3,0xe0,0x24,0x00,0x00,0x00,0x00,0xed);
		}	 
	}
	if(CanSendFlag.uvc == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.uvc == 1)
		{
			CanSendFlag.uvc = 0;
			Send_Packet(0xe3,0xe0,0x51,0x00,0x00,0x00,0x00,0xed);
		}	 
	}
	if(CanSendFlag.sip == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(CanSendFlag.sip == 1)
		{
			CanSendFlag.sip = 0;
			Send_Packet(0xe3,0xe0,0x52,0x00,0x00,0x00,0x00,0xed);
		}	 
	}
	if(Lock_Motor == 0xff)
	{
		_delay_us(CAN_SEND_DELAY);
		if(Lock_Motor == 0xff)
		{
			Lock_Motor = 0;
			Send_Packet(0xe3,0xe0,0x3a,1,0x00,0x00,0x00,0xed);
		}	 
	}
	if(Lock_Motor == 1)
	{
		_delay_us(CAN_SEND_DELAY);
		if(Lock_Motor == 1)
		{
			Lock_Motor = 0;
			Send_Packet(0xe3,0xe0,0x3a,0,0x00,0x00,0x00,0xed);
		}	 
	}*/
	if(Flag_System_Reset)
	{
		_delay_us(CAN_SEND_DELAY);
		if(Flag_System_Reset)
		{
			Flag_System_Reset = 0;
			Send_Packet(0xe3,0xe0,0xf4,0,0x00,0x00,0x00,0xed);
		}
	}
	if(Flag_State_Send == 0)
	{
		Flag_State_Send = 0;
		if(Status.up)
			state1 |= 0x01;
		else
			state1 &= 0xfe;
		if(Status.dn)
			state1 |= 0x02;
		else
			state1 &= 0xfd;
		if(Status.bu)
			state1 |= 0x04;
		else
			state1 &= 0xfb;
		if(Status.bd)
			state1 |= 0x08;
		else
			state1 &= 0xf7;	
		if(Status.Cup)
			state2 |= 0x01;
		else
			state2 &= 0xfe;
		if(Status.Rinse)
			state2 |= 0x02;
		else
			state2 &= 0xfd;
		if(Status.qx)
			state2 |= 0x04;
		else
			state2 &= 0xfb;
		if(Status.rx)
			state2 |= 0x08;
		else
			state2 &= 0xf7;
		if(Status.Lamp)
			state2 |= 0x10;
		else
			state2 &= 0xef;
		if(Status.gpd)
			state2 |= 0x20;
		else
			state2 &= 0xdf;
		if(Status.uvc)
			state2 |= 0x40;
		else
			state2 &= 0xbf;
		if(Status.sip)
			state2 |= 0x80;
		else
			state2 &= 0x7f;
		state3 = Status._Heat_;
		state4 = CupTemp.ReVal;
		state5 = Disp_cup;
		state6 = Disp_rinse;
		if((Flag_JXW_State&0x80)==0x80)	
			state7 |= 0x01;
		else
			state7 &= 0xfe;
		if((Flag_JXW_State&0x40)==0x40)
			state7 |= 0x02;
		else
			state7 &= 0xfd;
		if((Flag_JXW_State&0x20)==0x20)
			state7 |= 0x04;
		else
			state7 &= 0xfb;
		if((Flag_JXW_State&0x10)==0x10)
			state7 |= 0x08;
		else
			state7 &= 0xf7;
		if((Flag_JXW_State&0x04)==0x04)	
			state7 |= 0x10;
		else
			state7 &= 0xef;
		if((Flag_JXW_State&0x08)==0x08)
			state7 |= 0x20;
		else
			state7 &= 0xdf;
		if(Status.sp)
			state7 |= 0x40;
		else
			state7 &= 0xbf;
		if(Auto_Pos_EN)
			state7 |= 0x80;
		else
			state7 &= 0x7f;
		state8 = Set.Doctor;
		state9 = Angle_Y;
		state10 = Angle_Y_2;		
		
		gprsN11data.Txbuff[0] = 0xcd;
		gprsN11data.Txbuff[1] = 0xdc;
		if(Fault_Request == 1) {gprsN11data.Txbuff[2] = 0xfa;}
		else if(Flag_AutoTest_End == 1) {gprsN11data.Txbuff[2] = 0xfe;}
		else {gprsN11data.Txbuff[2] = 0x61;}
		gprsN11data.Txbuff[3] = state1;
		gprsN11data.Txbuff[4] = state2;
		gprsN11data.Txbuff[5] = state3;
		gprsN11data.Txbuff[6] = state4;
		gprsN11data.Txbuff[7] = state5;
		gprsN11data.Txbuff[8] = state6;
		gprsN11data.Txbuff[9] = state7;
		gprsN11data.Txbuff[10] = state8;
		gprsN11data.Txbuff[11] = state9;
		gprsN11data.Txbuff[12] = state10;
		gprsN11data.Txbuff[13] = state11;
		gprsN11data.Txbuff[14] = state12;
		gprsN11data.Txbuff[15] = 0xed;

//		Send_Packet_U3(0xcd,0xdc,0x61,state1,state2,state3,state4,state5,state6,state7,state8,state9,state10,state11,state12,0xed);
	}
}

