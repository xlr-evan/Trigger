
#include "analy.h"

/* ----------------------- Variables ----------------------------------------*/
static eMBEventType eQueuedEvent;
static u8     xEventInQueue;

/* ----------------------- Start implementation -----------------------------*/
//�¼���ʼ��
void xMBPortEventInit( void )
{
    xEventInQueue = 0;
		xMBPortEventPost(EV_REDY);
    
}
//�¼��ϱ�
void xMBPortEventPost( eMBEventType eEvent )
{
    xEventInQueue = 1;
    eQueuedEvent = eEvent;
}
//�¼���ȡ
u8 xMBPortEventGet( eMBEventType * eEvent )
{
    u8 xEventHappened = 0;

    if( xEventInQueue )
    {
        *eEvent = eQueuedEvent;
        xEventInQueue = 0;
        xEventHappened = 1;
    }
    return xEventHappened;
}


