
#include "analy.h"

/*------------------------------------------------------------
*协议解析:针对基于Modbus协议的从机发回的数据
*1.数据接收实现:1)、串口接收从机发来的数据。
                2)、定时器进行帧判断，以及超时机制。
*2.数据解析实现:1)、对接收到的有效数据进行CRC校验。
                2)、校验正确的数据帧，按照功能码进行处理。
*------------------------------------------------------------*/
u8 data_Tx[10] = {0};
int8_t Temp_buff[slaveNum] = {0};
u8 Hum_buff[slaveNum] = {0};
//温湿度显示缓冲区
/*-------------------------------
---C---H----L         3---2---1
---H---H----L         6---5---4
/=>0:0x3f,1:0x06,2:0x5b,3:0x4f,4:0x66,5:0x6d,6:0x7d,7:0x07,8:0x7f,9:0x6f
/=>a:0x77,b:0x7c,c:0x39,d:0x5e,e:0x79,f:0x71,H:0X76
*/
u8 Display_Num[10] ={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f}; //数字0~9
u8 Display_ErrorAdder[6] = {0x5e,0x5e,0x77,0x71,0x71,0x71};//地址错误
u8 Display_Adder[6] = {0x5e,0x5e,0x77,0x71,0x71,0x3f};//地址
u8 Display_ErrorData[6] = {0x77,0x5e,0x5e,0x71,0x71,0x71};//数据错误
u8 Display_TH[6] = {0x00,0x00,0x00,0x00,0x00,0x00}; //温湿度显示


u16 cal_CRC = 0;  //CRC校验值
static u8 slaveAdder = 0x01; //用于存储每次询问的从机地址，在数据解析时进行比对


//对从机，进行数据读写
//function:支持00,04,06; 寄存器起始地址最大为0xFF,寄存器数量最大为0xFF.
//约定每次读写一个字（16位的寄存器）
void Mster_Rw_data(void)
{	
	data_Tx[0] = slaveAdder; //打包轮询命令
	
	#if Rdata
	data_Tx[1] = 0x04;
	#elif Wdata
	data_Tx[1] = 0x06;
	#endif   
	
	data_Tx[2] = 0x00;
	data_Tx[4] = 0x00;
	data_Tx[5] = 0x00;
	data_Tx[5] = 0x01;
	cal_CRC=CRC_Compute(data_Tx,6); //计算校验值
	data_Tx[6] = cal_CRC >> 8; 
	data_Tx[7] = cal_CRC & 0x00ff;
	
	Uart1_sendDate(data_Tx,8);
	
	
}
//事件轮询，对收到的数据进行处理
void emPoll(void)
{	
	u8 i;
	static u8 Rx_state = 0;
	static u16 DATA_ERROR = 0,ADDER_ERROR = 0;
	eMBEventType eEvent; 
	
	if(xMBPortEventGet( &eEvent ) == 1)//获取当前事件
	{
		switch(eEvent)
		{
			case EV_REDY:
							DATA_ERROR = 0;//清零数据错误计数(询问下一个从机时，清零缓存区)
							ADDER_ERROR = 0;  //清零地址错误计数器		
							if(slaveAdder < slaveNum && slaveAdder > 0)//轮询下一个从机
							{
								slaveAdder += 1; //地址增1
							}else
							{ 
								slaveAdder = 0x01;
							}
							xMBPortEventPost(EV_FRAME_SENT);
							break;
							
			case EV_FRAME_SENT:
							//使能串口发送，发送查询指令，发送完成后使能串口接收
							Rx_state = 0; //清零接收数据状态(当数据错误时，清零缓存区)
							for(i=0;i<Rxcnt;i++) master_Rx_data[i] = 0;//清除缓存区
							Rxcnt = 0;	
							analySerialEnable(0,1);//使能485发送，关闭串口接收中断
							Mster_Rw_data();//发送询问从机的命令
							analySerialEnable(1,0);//使能485接收，打开串口接收中断
							analyTimersEnable();//超时等待计时器（500ms从机没回应，再次发送轮询命令）
							break;
              
			case EV_DATA_RECEIVED://接收数据                                              
							switch(Rx_state)
							{
								case 0:
									ADDER_ERROR = 0;  //清零地址错误计数器
									analyTimersDisable();//关闭超时定时器
									Rx_state = 1;
									break;
								case 1: //接收数据
									break;
							}					
						  break;							
							
			case EV_EXECUTE://数据进行处理
							if(CRC_Compute(master_Rx_data,Rxcnt))//CRC校验
							{
							  xMBPortEventPost(EV_DATA_ERROR);
							  break;
							}							
							if(!(master_Rx_data[0] == slaveAdder && master_Rx_data[1] ==0x04 && master_Rx_data[2] == 0X02))//帧头校验
							{
							  xMBPortEventPost(EV_DATA_ERROR);
							  break;
							}
							Temp_buff[slaveAdder-1] = master_Rx_data[3] - 40;//提取温度
							Hum_buff[slaveAdder-1] = master_Rx_data[4];//提取湿度						
							if(Hum_buff[slaveAdder-1] > 100) //当湿度大于100时，上报数据错误
							{
								xMBPortEventPost(EV_DATA_ERROR);
							}else
							{
								Display_Adder[4] = Display_Num[slaveAdder/10];
								Display_Adder[3] = Display_Num[slaveAdder%10];
								TM1640_Display(Display_Adder); //数码管显示地址	
								delay_ms(1200);
								if(Temp_buff[slaveAdder-1] < -9)//温度显示
								{
										Display_TH[2] = 0x40;
										Display_TH[1] = Display_Num[(-Temp_buff[slaveAdder-1])  / 10];
										Display_TH[0] = Display_Num[(-Temp_buff[slaveAdder-1]) % 10];
								}else if(Temp_buff[slaveAdder-1] < 0)
								{
										Display_TH[2] = 0x00;
										Display_TH[1] = 0x40;
										Display_TH[0] = Display_Num[(-Temp_buff[slaveAdder-1]) % 10];
								}else if(Temp_buff[slaveAdder-1] < 10)
								{
										Display_TH[2] = 0x00;
										Display_TH[1] = 0x00;
										Display_TH[0] = Display_Num[Temp_buff[slaveAdder-1] % 10];
								}else if(Temp_buff[slaveAdder-1] < 99)
								{
										Display_TH[2] = 0x00;
										Display_TH[1] = Display_Num[Temp_buff[slaveAdder-1]  / 10];
										Display_TH[0] = Display_Num[Temp_buff[slaveAdder-1] % 10];
								}else
								{
										Display_TH[2] = Display_Num[Temp_buff[slaveAdder-1]  / 100];
										Display_TH[1] = Display_Num[Temp_buff[slaveAdder-1] %100 / 10];
										Display_TH[0] = Display_Num[Temp_buff[slaveAdder-1] %100 %10];
								}
								if(Hum_buff[slaveAdder-1]>99)//湿度显示
								{
										Display_TH[5] = Display_Num[Hum_buff[slaveAdder-1] / 100];
										Display_TH[4] = Display_Num[Hum_buff[slaveAdder-1] % 100 / 10];
										Display_TH[3] = Display_Num[Hum_buff[slaveAdder-1] % 100 % 10];
								}else if(Hum_buff[slaveAdder-1]>9)
								{
										Display_TH[5] = 0x00;
										Display_TH[4] = Display_Num[Hum_buff[slaveAdder-1] / 10];
										Display_TH[3] = Display_Num[Hum_buff[slaveAdder-1] % 10];
								}else 
								{
										Display_TH[5] = 0x00;
										Display_TH[4] = 0x00;
										Display_TH[3] = Display_Num[Hum_buff[slaveAdder-1] % 10];
								}
								TM1640_Display(Display_TH); //数码管显示 
								delay_ms(1000);
								xMBPortEventPost(EV_REDY);  //上报准备事件
						}
						break;
									
			case EV_DATA_ERROR://接收数据异常,关闭串口1，上报再次轮询事件
							DATA_ERROR++;
							analySerialEnable(0,0);
							if(DATA_ERROR > 3)
							{
								DATA_ERROR = 0;
								TM1640_Display(Display_ErrorData); //数码管显示 
								xMBPortEventPost(EV_REDY);//轮询下一个从机
							}else{
								Temp_buff[slaveAdder-1] = 0;
								Hum_buff[slaveAdder-1] = 0;
								xMBPortEventPost(EV_FRAME_SENT);
							}
							break;
						
			case  EV_SLAVE_ERROR://从机不在线
							ADDER_ERROR++;
							if(ADDER_ERROR > 2)
							{
								ADDER_ERROR = 0;
								Display_ErrorAdder[5] = Display_Num[slaveAdder/10];
								Display_ErrorAdder[4] = Display_Num[slaveAdder%10];
								TM1640_Display(Display_ErrorAdder); //数码管显示 
								xMBPortEventPost(EV_REDY);//轮询下一个从机
							}else{
								Temp_buff[slaveAdder-1] = 0;
								Hum_buff[slaveAdder-1] = 0;
								xMBPortEventPost(EV_FRAME_SENT);
							}
							break;
		}
	}
}

//温湿度求平均值
int8_t equal_T(void)
{
	int equal= 0;
	u8 i,cnt=0;
	
	for(i=0;i<3;i++)
	{
		if(Hum_buff[i] <= 100)
		{
			equal += Temp_buff[i];
			cnt++;
		}
	}
	equal = equal / cnt;
	return (int8_t)equal;
}
//温湿度求平均值
u8 equal_H(void)
{
	u16 equal= 0;
	u8 i,cnt=0;
	
	for(i=0;i<3;i++)
	{
		if(Hum_buff[i] <= 100)
		{
			equal += Hum_buff[i];
			cnt++;			
		}
	}
	equal = equal / cnt;
	return (u8)equal;
}

