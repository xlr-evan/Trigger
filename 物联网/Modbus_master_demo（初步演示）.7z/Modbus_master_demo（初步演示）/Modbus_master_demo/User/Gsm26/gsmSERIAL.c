
#include "gsm26.h"
#include "string.h"

u8 M26_Rxbuf[uart3_max_recv_len] = {0};
u8 M26_Txbuf[uart3_max_send_len] = {0};

u8 uart3_Rx_STA = 0;

/**
  * @brief  从串口获得数据
  * @param  None
  * @retval None
  */
void USART3_IRQHandler(void)
{
	u8 data;
	if(USART_GetITStatus(USART3,USART_IT_RXNE)!=RESET)
	{
		data=USART_ReceiveData(USART3);
		if((uart3_Rx_STA & 1<<7) == 0)//接收完一批数据，还没有被处理则，不再接收数据
		{	
			if(uart3_Rx_STA < uart3_max_recv_len)
			{
				TIM_SetCounter(TIM3,0);             //计数器清空 
				if(uart3_Rx_STA == 0)
				{
					TIM_Cmd(TIM3,ENABLE);           //使能定时器3
				}
				M26_Rxbuf[uart3_Rx_STA++] = data; //缓存接收到的值
			}else 
			{
				uart3_Rx_STA |= 1 << 7; //强制标记完成
			}   
		}

    }
}
/**
  * @brief  串口初始化
  * @param  ulBaudRate  波特率
  * @retval None
  */
void Gsm_serialinit(u32 BaudRate)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  
   //使能USART3,GPIOB
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //GPIOB时钟
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);  //串口3时钟使能
  
  USART_DeInit(USART3);  //复位串口3	
  //GPIOB10 USART3_Tx
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;             //复用推挽输出
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  //GPIOB11 USART1_Rx
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;       //浮空输入
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  USART_InitStructure.USART_BaudRate = BaudRate;            //波特率
  USART_InitStructure.USART_WordLength = USART_WordLength_8b; //字长为8位
  USART_InitStructure.USART_StopBits = USART_StopBits_1;  //1位停止位
  USART_InitStructure.USART_Parity = USART_Parity_No;   //无奇偶校验
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//收发模式
 
  USART_Init(USART3, &USART_InitStructure); //串口3初始化
  USART_Cmd(USART3, ENABLE);//使能串口
  USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);//使能UART3接收中断
  
  //设置中断优先级
  NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0 ;//抢占优先级2
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//子优先级3
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
  NVIC_Init(&NVIC_InitStructure);	//根据指定的参数初始化NVIC寄存器
	
  gsmTimersInit(99,7199); //10ms中断
  uart3_Rx_STA  = 0;//清零
  TIM_Cmd(TIM3,DISABLE);//关闭定时器7
}
/**
  * @brief  通过串口发送数据
  * @param  None
  * @retval None
  */
void Uart3_sendDate(char *buf,...)
{
	u16 i,j; 
	va_list ap; 
	va_start(ap,buf);
	vsprintf((char*)M26_Txbuf,buf,ap);
	va_end(ap);
	i=strlen((const char*)M26_Txbuf);	
	for(j=0;j<i;j++)							//循环发送数据
	{
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==RESET); //直到发送完成   
		USART_SendData(USART3,M26_Txbuf[j]); 
	}
}










