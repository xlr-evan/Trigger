
#include "gsm26.h"
#include "analy.h"

u8 Dis_smsERROR[6] = {0x6d,0x37,0x6d,0x71,0x71,0x71}; //短信发送失败，开启重发
u8 Dis_smsSUCCS[6] = {0x6d,0x37,0x6d,0x6f,0x6f,0x6f}; //短信发送失败，开启重发
u8 Dis_smsRec1[6] = {0x6d,0x37,0x6d,0x06,0x06,0x06}; //接收到147
u8 Dis_smsRec2[6] = {0x6d,0x37,0x6d,0x5b,0x5b,0x5b}; //接收到258
u8 Dis_smsRec3[6] = {0x6d,0x37,0x6d,0x4f,0x4f,0x4f}; //接收到369
u8 Dis_smsRecError[6] = {0x6d,0x37,0x6d,0x3f,0x3f,0x3f}; //接收到错误指令
char *sms_HELP = "003100340037FF1A67E58BE26E296E7F5EA6FF0C003200350038FF1A8BBE7F6E9AD86E2962A58B66FF0C003300360039FF1A8BBE7F6E4F4E6E2962A58B66FF0C003000300030FF1A53D66D886E295EA698848B663002";//147：查询温湿度，258：设置高温报警，369：设置低温报警。
char *sms_Warn = "5F53524D6E296E7F5EA65F025E38FF0C8BF753CA65F651736CE8FF01";//当前温湿度异常，请及时关注！
char *sms_cancel = "6E295EA698848B6653D66D886210529FFF01";//温度预警取消成功！

u8 H_warn = 0,L_warn = 0,warn_lock = 0;
u8 warnTH = 0,warnTL = 0,warnHen = 0,warnLen = 0; //温度预警值

//M26任务轮询
void gsmPoll(char *Temp,char *Hum)
{
	u8 len = 0;//存储字符长度
	u8 Num_offset = 0; //判断号码是91/A1
	static u8 cout = 0;//短信重发计数器
	static u8 IDLE_STA = 0;//空闲事件下的状态变量
	static u8 INFOR_STA = 0; //短信状态变量
	static char sms_Num[20] = {0}; //存放查询温湿度的号码信息
	static char sms_WarnNum[20] = {0};//存放预警信息的号码信息
	char *sms_Str = NULL; //辅助号码提取
	char sms_buff[300] = {0};//信息缓存
	char sms_data[200] = {0};//信息数据缓存
	char strbuf[50] = {0};//写短信指令缓存
	
	gsmEventType Task; //事件枚举
	
	if(warn_lock == 1 && (H_warn == 1 || L_warn == 1)) //检测温湿度是否异常，且间隔时间已到
	{
		warn_lock = 0;
		H_warn = 0;
		L_warn = 0;
		INFOR_STA = 4;
		gsmEventPost(gsm_REDY); //发送预警信息
	}
	if(gsmEventGet( &Task ) == 1)//获取当前事件
	{
		switch(Task)
		{
			case gsm_IDLE:  //空闲状态,1:获取用户的短信，依据指令进行操作。
     						switch(IDLE_STA)
								{
								case 0:
										if(gsm_send_cmd("AT+CMGL=4,0","089168",200) == 0)//读取接收到的短信
										{
											if(strstr((const char*)M26_Rxbuf,(const char*)"0D9168") != NULL)
											{
												Num_offset = 26;
											}else Num_offset = 24;
											
											if(strstr((const char*)M26_Rxbuf,(const char*)"230331DA0D") != NULL) //查询指令"147"
											{
												sms_Str = strstr((const char*)M26_Rxbuf,(const char*)"089168");
												strncpy(sms_Num,sms_Str+Num_offset,12);//提取号码
												sms_WarnNum[12] = '\0'; //避免乱码
												INFOR_STA = 1; //向来信用户发送温湿度
												IDLE_STA = 1;//转到状态2	
												gsmEventPost(gsm_IDLE);	//上报空闲事件转到状态2	
											}else if(strstr((const char*)M26_Rxbuf,(const char*)"2303B21A0E") != NULL)//设置高温预警指令"258"
											{										
												sms_Str = strstr((const char*)M26_Rxbuf,(const char*)"089168");
												strncpy(sms_WarnNum,sms_Str+Num_offset,12);//提取预警接收号码
												sms_WarnNum[12] = '\0'; //避免乱码	
												warnTH = 32;  //报警温度设为30
												warnHen = 1;  //高温使能	
												INFOR_STA = 2; //向来信用户发送设置高温预警
												IDLE_STA = 1;
												gsmEventPost(gsm_IDLE);	//上报空闲事件转到状态3
											}else if(strstr((const char*)M26_Rxbuf,(const char*)"2303335B0E") != NULL)//设置低温预警指令"369"
											{
												sms_Str = strstr((const char*)M26_Rxbuf,(const char*)"089168");
												strncpy(sms_WarnNum,sms_Str+Num_offset,12);//提取预警接收号码
												sms_WarnNum[12] = '\0'; //避免乱码	
												warnTL = 10; //报警温度设为5	
												warnLen = 1;	//低温使能		
												INFOR_STA = 3; //向来信用户发送低温温预警											
												IDLE_STA = 1;
												gsmEventPost(gsm_IDLE);	//上报空闲事件转到状态4
											}else if(strstr((const char*)M26_Rxbuf,(const char*)"230330180C") != NULL)//取消报警指令"000"
											{
												sms_Str = strstr((const char*)M26_Rxbuf,(const char*)"089168");
												strncpy(sms_WarnNum,sms_Str+Num_offset,12);//提取预警接收号码
												sms_WarnNum[12] = '\0'; //避免乱码
												warnTL = 0; //报警温度设为0
												warnTH = 0;  //报警温度设为0
												warnLen = 0;
												warnHen = 0;
												INFOR_STA = 5; //取消温度预警
												IDLE_STA = 1;
												gsmEventPost(gsm_IDLE);
											}else  //提示用户如何操作
											{
												sms_Str = strstr((const char*)M26_Rxbuf,(const char*)"089168");
												strncpy(sms_Num,sms_Str+Num_offset,12);//提取号码
												sms_Num[12] = '\0'; //避免乱码
												INFOR_STA = 0; //向来信用户发送短信菜单
												IDLE_STA = 1;
												gsmEventPost(gsm_IDLE);//上报空闲事件，转到状态1
											}																					
										}else gsmEventPost(gsm_IDLE);//上报空闲事件
										break;
								case 1:if(gsm_send_cmd("AT+QMGDA=6","OK",200) == 0) //删除所有短信
										{
											IDLE_STA = 0; //回到读短信状态
											gsmEventPost(gsm_REDY); //上报发送用户可选项短信事件
										}else gsmEventPost(gsm_IDLE);//上报空闲事件
										break;
							}
							break;
			case gsm_REDY:  //发送短信准备事件
							IWDG_Feed();//喂狗
							if(gsm_send_cmd("AT+CREG?","+CREG: 0,1",200) == 0)
							{
								if(gsm_send_cmd("AT+CSCS=\"GSM\"","OK",200) == 0)
								{
									if(gsm_send_cmd("AT+CMGF=0","OK",200) == 0)
									{
										gsmEventPost(gsm_INFOR);  //发短信前保证设置好短信相关配置信息
									}else gsmEventPost(gsm_REDY);
								}else gsmEventPost(gsm_REDY);
							}else gsmEventPost(gsm_REDY);										
							break;
			case gsm_REPORT:  //信息发送失败
							TM1640_Display(Dis_smsERROR); //显示发送失败信息
							cout++;
							if(cout > 2)
							{
								cout = 0;
								gsmEventPost(gsm_IDLE);//上报空闲事件，终止此次短信
							}else gsmEventPost(gsm_INFOR); //上报短信发送事件
							break;
			case gsm_INFOR:  //信息发送	
							IWDG_Feed();//喂狗
							USART_ITConfig(USART1, USART_IT_RXNE, DISABLE); //禁止Modbus接受中断
							TIM_ITConfig(TIM4, TIM_IT_Update, DISABLE);
							switch(INFOR_STA)
							{
								case 0: //回复用户可选项
										len = strlen(sms_HELP)/2;//计算数据长度
										sprintf(sms_buff,"0031000D9168%s000800%x%s",sms_Num,len,sms_HELP);//打包短信
										len = strlen(sms_buff)/2 -1; //减去SCA字节
										sprintf(strbuf,"AT+CMGS=%d",len);
										if(gsm_send_cmd("AT+CREG?","+CREG: 0,1",200))
										{
											gsmEventPost(gsm_REDY);//发送前再次检测网络是否注册,没注册上报准备事件
										}
										if(gsm_send_cmd(strbuf,">",200) == 0)
										{
											Uart3_sendDate("%s",sms_buff);
											if(gsm_send_cmd((char*)0x1A,"OK",600) == 0) //等待发送成功
											{
												TM1640_Display(Dis_smsSUCCS); //显示发送成功信息	
											}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件
										}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件	
										break;
								case 1: //在123指令下，回复来信手机当前温湿度数据
										sprintf(sms_data,"5F53524D6E295EA6662F%s00B00043FF0C6E7F5EA6662F%s00253002",Temp,Hum);//打包数据：“温度是xx°C，湿度是xx%。”
										len = strlen(sms_data)/2;//计算数据长度
										sprintf(sms_buff,"0031000D9168%s000800%x%s",sms_Num,len,sms_data);//打包短信
										len = strlen(sms_buff)/2 -1; //减去SCA字节
										sprintf(strbuf,"AT+CMGS=%d",len);
										if(gsm_send_cmd("AT+CREG?","+CREG: 0,1",200))
										{
											gsmEventPost(gsm_REDY);//发送前再次检测网络是否注册,没注册上报准备事件
										}
										if(gsm_send_cmd(strbuf,">",200) == 0)
										{
											Uart3_sendDate("%s",sms_buff);
											if(gsm_send_cmd((char*)0x1A,"OK",600) == 0) //等待发送成功
											{
												TM1640_Display(Dis_smsSUCCS); //显示发送成功信息		
											}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件
										}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件	
										break;
								case 2://回复高温度预警成功信息
										sprintf(sms_data,"9AD86E2998848B668BBE7F6E6210529FFF0C98848B666E295EA64E3A003%d003%d00B000433002",warnTH/10,warnTH%10);
										len = strlen(sms_data)/2;//计算数据长度
										sprintf(sms_buff,"0031000D9168%s000800%x%s",sms_WarnNum,len,sms_data);//打包短信
										len = strlen(sms_buff)/2 -1; //减去SCA字节
										sprintf(strbuf,"AT+CMGS=%d",len);
										if(gsm_send_cmd("AT+CREG?","+CREG: 0,1",200))
										{
											gsmEventPost(gsm_REDY);//发送前再次检测网络是否注册,没注册上报准备事件
										}
										if(gsm_send_cmd(strbuf,">",200) == 0)
										{
											Uart3_sendDate("%s",sms_buff);
											if(gsm_send_cmd((char*)0x1A,"OK",600) == 0) //等待发送成功
											{
												TM1640_Display(Dis_smsSUCCS); //显示发送成功信息
											}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件
										}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件	
										break;
								case 3://回复低温度预警成功信息
										sprintf(sms_data,"4F4E6E2998848B668BBE7F6E6210529FFF0C98848B666E295EA64E3A003%d003%d00B000433002",warnTL/10,warnTL%10);
										len = strlen(sms_data)/2;//计算数据长度
										sprintf(sms_buff,"0031000D9168%s000800%x%s",sms_WarnNum,len,sms_data);//打包短信
										len = strlen(sms_buff)/2 -1; //减去SCA字节
										sprintf(strbuf,"AT+CMGS=%d",len);
										if(gsm_send_cmd("AT+CREG?","+CREG: 0,1",200))
										{
											gsmEventPost(gsm_REDY);//发送前再次检测网络是否注册,没注册上报准备事件
										}
										if(gsm_send_cmd(strbuf,">",200) == 0)
										{
											Uart3_sendDate("%s",sms_buff);
											if(gsm_send_cmd((char*)0x1A,"OK",600) == 0) //等待发送成功
											{
												TM1640_Display(Dis_smsSUCCS); //显示发送成功信息
											}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件
										}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件	
										break;
								case 4: //预警信息
										sprintf(sms_data,"%s5F53524D6E295EA6662F%s00B00043FF0C6E7F5EA6662F%s00253002",sms_Warn,Temp,Hum);
										len = strlen(sms_data)/2;//计算数据长度
										sprintf(sms_buff,"0031000D9168%s000800%x%s",sms_WarnNum,len,sms_data);//打包短信
										len = strlen(sms_buff)/2 -1; //减去SCA字节
										sprintf(strbuf,"AT+CMGS=%d",len);
										if(gsm_send_cmd("AT+CREG?","+CREG: 0,1",200))
										{
											gsmEventPost(gsm_REDY);//发送前再次检测网络是否注册,没注册上报准备事件
										}
										if(gsm_send_cmd(strbuf,">",200) == 0)
										{
											Uart3_sendDate("%s",sms_buff);
											if(gsm_send_cmd((char*)0x1A,"OK",600) == 0) //等待发送成功
											{
												TM1640_Display(Dis_smsSUCCS); //显示发送成功信息	
											}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件		
										}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件	
										break;
								case 5: //取消预警信息
										len = strlen(sms_cancel)/2;//计算数据长度
										sprintf(sms_buff,"0031000D9168%s000800%x%s",sms_WarnNum,len,sms_cancel);//打包短信
										len = strlen(sms_buff)/2 -1; //减去SCA字节
										sprintf(strbuf,"AT+CMGS=%d",len);
										if(gsm_send_cmd("AT+CREG?","+CREG: 0,1",200))
										{
											gsmEventPost(gsm_REDY);//发送前再次检测网络是否注册,没注册上报准备事件
										}
										if(gsm_send_cmd(strbuf,">",200) == 0)
										{
											Uart3_sendDate("%s",sms_buff);
											if(gsm_send_cmd((char*)0x1A,"OK",600) == 0) //等待发送成功
											{
												TM1640_Display(Dis_smsSUCCS); //显示发送成功信息	
											}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件		
										}else gsmEventPost(gsm_REPORT);//上报发送错误报告事件	
										break;
							}	
							TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE); //使能定时器
							USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); //使能Modbus接受中断
							xMBPortEventPost(EV_DATA_ERROR);
							break;
		}
	}
}
/**
	* @brief  GSM模块初始化
	* @param  None
	*    
	* @retval None
	*/
u8 Gsm_m26init(void)
{
	//初始化PA.4,即M26开机引脚
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;				 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
	GPIO_Init(GPIOA, &GPIO_InitStructure);	
	//POWER_KEY->GPIOA.4,拉高,开机M26模块
	POWER_KEY = 1; //开机
	delay_ms(1000); //等待一段时间
	
	gsmEventInit();//事件初始化

	//配置串口波特率，M26回显模式
	if(gsm_send_cmd("AT","OK",200)) return 1; //确认开机成功
	if(gsm_send_cmd("AT+QVBATT=0,3500,0","OK",200)) return 2; //关闭低压URC信息	
	if(gsm_send_cmd("AT+IPR=115200;&W","OK",200)) return 3; //设置端口波特率
	if(gsm_send_cmd("AT+QMGDA=6","OK",200)) return 4;//删除所有短信
	
	return 0;
}
/**
	* @brief  查找期望的应答
	* @param  str:期望字符串
	*    
	* @retval 0:没有找到;期望字符串及其后的字符
	*/
u8* gsm_check_cmd(char *str)
{
	char *strx=0;
	if(uart3_Rx_STA&0x80)		//接收到一次数据了
	{ 
		uart3_Rx_STA = 0;//添加结束符
		strx=strstr((const char*)M26_Rxbuf,(const char*)str);
	} 
	return (u8*)strx;
}
/**
	* @brief  发送AT命令（不需添加\r\n）,检测期望的应答
	* @param  cmd:AT指令 ack:期望应答 waittime:等待时间
	*    
	* @retval 1:无应答或非期望应答。0：期望应答
	*/
u8 gsm_send_cmd(char *cmd,char *ack,u16 waittime)
{
	u8 res = 0;
	uart3_Rx_STA = 0;
	if((u32)cmd <= 0xff)
	{
		while((USART3->SR&0x40) == 0); //等待上一次数据发完		
		 USART3->DR = (u32)cmd;
	}
	else Uart3_sendDate("%s\r\n",cmd); //发送命令
	
	if(ack && waittime) //需要应答
	{
		while(--waittime)
		{
			delay_ms(10);
			if(uart3_Rx_STA & 0x80) //接收到一批数据
			{
				if(gsm_check_cmd(ack)) break; //得到期望应答
			}
		}
		if(waittime == 0) res = 1;
	}
	return res;
}	
/**
	* @brief  检测期望的应答
	* @param  waittime:时间 request:期望应答
	*    
	* @retval 1:无应答或非期望应答。0：期望应答
	*/
u8 gsm_wait_request(char *request ,u16 waittime)
{
	 u8 res = 0;
	 if(request && waittime)
	 {
	    while(--waittime)
		{   
		   delay_ms(10);
		   if(uart3_Rx_STA &0x80)//接收到期待的应答结果
		   {
				if(gsm_check_cmd(request)) break;//得到有效数据
		   }
		}
		if(waittime==0)res=1;
	 }
	 return res;
}



