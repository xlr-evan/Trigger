
#include "gsm26.h"

/* ----------------------- Variables ----------------------------------------*/
static gsmEventType gEvent;
static u8     xEvent;

/* ----------------------- Start implementation -----------------------------*/
//�¼���ʼ��
void gsmEventInit( void )
{
    xEvent = 0;
}
//�¼��ϱ�
void gsmEventPost( gsmEventType eEvent )
{
    xEvent = 1;
    gEvent = eEvent;
}
//�¼���ȡ
u8 gsmEventGet( gsmEventType * eEvent )
{
    u8 xEventHappened = 0;

    if( xEvent )
    {
        *eEvent = gEvent;
        xEvent = 0;
        xEventHappened = 1;
    }
    return xEventHappened;
}


