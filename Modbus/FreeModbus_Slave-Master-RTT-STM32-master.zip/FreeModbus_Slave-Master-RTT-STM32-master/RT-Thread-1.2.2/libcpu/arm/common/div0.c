void __div0 (void)
{
	while (1) ;
}
